---
name: design-system-forge
description: "Reverse-engineer, analyze, and generate complete design system specifications from any visual input — URLs, images, documents, publications, or descriptions. Use this skill whenever someone asks to analyze a design, extract a design system, create a design system from scratch or from examples, build a style guide, create design tokens, generate implementation specs for UI/documents/presentations/emails, or produce agent-interpretable design specifications. Also triggers on requests to identify design influences, trace design lineage, compare design systems, or produce cross-medium implementation guides. This skill covers ALL design system work: rationalist/Swiss, expressive/brand, motion-heavy, 3D/spatial, culturally-specific, generative/parametric, data-dense, and analog/handcraft traditions."
---

# Design System Forge

A comprehensive skill for reverse-engineering design influences from visual samples and synthesizing them into complete, agent-interpretable design system specifications.

## What This Skill Does

Given any visual input (website URL, screenshot, document, publication, or written description), this skill executes a multi-phase pipeline:

**Phase A — Analysis:** Perform a visual autopsy of the sample, identifying every observable design characteristic across typography, color, grid, spacing, motion, iconography, components, and overall aesthetic character.

**Phase B — Influence Research:** Trace the sample's design lineage to its artistic, typographic, industrial, and digital ancestors using web search. Produce a structured influence dossier.

**Phase C — Synthesis:** Weave identified influences into concrete design values using documented derivation procedures, producing a complete token-based specification.

**Phase D — Generation:** Output a machine-interpretable design system spec (YAML) and a human/agent implementation guide (Markdown), covering all target media.

**Phase E — Quality Assurance:** Validate the spec against a deterministic checklist and test runner framework.

## When to Read Which Reference File

The skill is modular. Read only what the current task requires.

### Core Pipeline (read in order for full pipeline execution)

| Step | File | Read When |
|------|------|-----------|
| 1 | `references/02-analysis-prompt.md` | Analyzing a design sample |
| 2 | `references/03-influence-catalog.md` | Identifying design influences |
| 3 | `references/04-synthesis-method.md` | Deriving concrete token values |
| 4 | `references/01-template.yaml` | Filling out the spec structure |
| 5 | `references/05-generation-prompt.md` | Generating the full spec + guide |
| 6 | `references/06-implementation-template.md` | Writing the implementation guide |
| 7 | `references/07-qa-framework.md` | Validating the output |

### Extension Modules (read when the sample exhibits these characteristics)

| Characteristic Detected | Extension File |
|------------------------|---------------|
| Illustration, photography, brand personality, editorial voice | `references/extensions/expressive-brand.md` |
| Physics-based animation, gesture vocabulary, choreography | `references/extensions/motion-interaction.md` |
| AR/VR/XR, depth, materials, spatial audio | `references/extensions/spatial-3d.md` |
| Non-Western typography, cultural color symbolism, RTL-first | `references/extensions/cultural-traditions.md` |
| Algorithmic variation, generative identity, parametric rules | `references/extensions/generative-parametric.md` |
| Terminal UI, trading platforms, medical/scientific density | `references/extensions/data-dense.md` |
| Texture, grain, hand-drawn, risograph, letterpress | `references/extensions/analog-handcraft.md` |
| Contextual overrides, judgment calls, underdetermined rules | `references/extensions/adaptive-systems.md` |

## Quick-Start: Common Tasks

### Task: "Analyze this design / website / screenshot"
1. Read `references/02-analysis-prompt.md`
2. Perform the visual autopsy on the provided sample
3. Use web search to identify the typeface, color system, and grid structure
4. Deliver a structured analysis report

### Task: "Create a design system from this example"
1. Read `references/02-analysis-prompt.md` → analyze the sample
2. Read `references/03-influence-catalog.md` → identify influences via research
3. Read `references/04-synthesis-method.md` → derive concrete values
4. Read `references/01-template.yaml` → fill every section
5. Read `references/06-implementation-template.md` → write the implementation guide
6. Read `references/07-qa-framework.md` → validate
7. Read any applicable extension modules
8. Output: `design-system-spec.yaml` + `IMPLEMENTATION.md`

### Task: "Create a design system from scratch" (no sample)
1. Read `references/05-generation-prompt.md` → follow the from-scratch procedure
2. Read `references/01-template.yaml` → fill every section
3. Read any applicable extension modules
4. Output: `design-system-spec.yaml` + `IMPLEMENTATION.md`

### Task: "What are the design influences of X?"
1. Read `references/02-analysis-prompt.md` → analyze the sample
2. Read `references/03-influence-catalog.md` → match observations to influences
3. Output: `design-influences-research.md`

## Extension Detection Heuristics

During Phase A (analysis), if you observe any of the following, load the corresponding extension module BEFORE proceeding to Phase B:

**Load `expressive-brand.md` if:** Custom illustrations are present. Photography has a distinctive art direction (not stock). The design has a perceptible "personality" or "voice." Color usage is emotionally expressive rather than purely functional.

**Load `motion-interaction.md` if:** Animations are prominent and complex. Scroll-driven effects are present. Transitions feel physics-based (springy, bouncy, inertial). Gesture interactions are defined.

**Load `spatial-3d.md` if:** The interface operates in three dimensions. Depth cues go beyond flat layering (perspective, lighting, materials). The target includes AR/VR/XR contexts.

**Load `cultural-traditions.md` if:** The primary language is non-Latin script (CJK, Arabic, Devanagari, etc.). Color choices reflect cultural symbolism beyond Western conventions. Layout direction is RTL-primary. Typographic traditions differ from Western norms.

**Load `generative-parametric.md` if:** Visual elements show algorithmic variation. Identity marks are generated, not fixed. Rules produce a family of outputs rather than a single canonical form.

**Load `data-dense.md` if:** Information density is very high. Components are smaller than 32px height. The UI appears optimized for expert/professional users who need simultaneous visibility of many data points.

**Load `analog-handcraft.md` if:** Textures, grain, or noise are present. Hand-drawn or hand-lettered elements appear. The design deliberately embraces imperfection. Print-craft aesthetics (letterpress, risograph, woodblock) are evident.

**Load `adaptive-systems.md` if:** The system appears to have contextual rules that change based on content type, user role, or viewport. Some design decisions appear intentionally underdetermined to allow for judgment.

## Output File Specifications

All outputs should be saved to the working directory and presented to the user.

**Primary outputs:**
- `design-system-spec.yaml` — Complete, parseable YAML specification (700-2000 lines depending on complexity and extensions)
- `IMPLEMENTATION.md` — Agent/developer implementation guide (500-1500 lines)

**Intermediate output (when analysis-only is requested):**
- `design-influences-research.md` — Influence dossier (2000-5000 words)

**QA output (when validation is requested):**
- `compliance-report.json` — Test results with pass/fail/skip per test ID

## Philosophy

This skill exists to bridge the gap between human aesthetic mastery and machine execution fidelity. The design masters — Vignelli, Rams, Müller-Brockmann, Scher — achieved their work through decades of cultivated judgment. An AI agent achieves comparable results through exhaustive specification and unwavering consistency. Neither approach is superior; they are complementary. This skill encodes the former into a format the latter can execute.

The goal is not to replace human designers but to give AI agents the vocabulary, grammar, and taste to produce work that honors the traditions it descends from.
