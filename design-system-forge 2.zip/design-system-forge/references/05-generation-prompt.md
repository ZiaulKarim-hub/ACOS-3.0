# System Generation Prompt — Produce a Complete Design System

## When to Use This File

Use this prompt when generating the final `design-system-spec.yaml` and `IMPLEMENTATION.md` outputs. This prompt assumes you have already completed analysis (02) and synthesis (04), and have a completed influence dossier. If starting from scratch without a sample, follow this prompt directly and make explicit design choices at each step.

---

## The Prompt

You are generating a complete, machine-interpretable design system specification. You have three inputs: (1) a completed influence dossier, (2) the synthesis method, and (3) the template structure. Your output is two files that, together, enable any AI agent to produce visually cohesive work across all target media — without seeing the output.

### Execution Checklist

Follow every step. Mark each complete before proceeding.

**Step 1: Read Meta.** Check which extensions are active in the influence dossier. Load the corresponding extension reference files from `references/extensions/`. These augment the template with additional sections and fields.

**Step 2: Choose Typeface.** Open-source, humanist or neo-grotesque sans-serif with Regular through Bold weights plus monospace companion. If cultural extension is active, add script-specific families. If expressive extension is active, add a display face. Specify exact name, fallback stack, weight range, and source URL.

**Step 3: Build Grid.** 16-column, 8px base unit, 32px gutter, 5 breakpoints. If data-dense is active, add ultra-condensed mode (1px or 0px gutter). If spatial-3d is active, define 3D coordinate system and depth layers.

**Step 4: Construct Color.** 8+ palettes × 10 grades. 4 themes. ~50-60 core tokens. Verify all text/background pairs against WCAG 2.1 AA. If expressive is active, add gradient tokens. If cultural is active, add cultural semantics mapping.

**Step 5: Type Scale & Tokens.** 15-step scale, ~25 tokens in 4 groups. If data-dense, prepend micro sizes (10-11px). If expressive, add display tokens with secondary face. Each token: font-size, line-height, weight, letter-spacing, usage.

**Step 6: Spacing.** 13-step component scale + 7-step layout scale. If data-dense, add micro scale. If expressive, extend layout scale upward.

**Step 7: Motion.** 2 personalities × 3 curves + 6 durations. If motion-interaction is active: add spring presets, gesture vocabulary, state machines, choreography sequences, haptic definitions, scroll effects, and reduced-motion policy.

**Step 8: Iconography.** UI icons (4 sizes, 10 categories) + pictograms (4 sizes). If analog-handcraft, define hand-drawn icon variant rules.

**Step 9: Components.** ≥35 components in 8 groups. Each: id, variants, sizes, states, anatomy, rules. If motion-interaction active: add behavior field. If data-dense: add 2xs/xs sizes. If adaptive: note contextual overrides.

**Step 10: Patterns.** ≥10 recurring solutions. List components used and layout rules.

**Step 11: Data Viz.** ≥12 chart types. Categorical color sequence. Labeling rules.

**Step 12: Globals.** 5-7 principles. Layer model, focus model, responsive strategy, RTL. Medium-specific variables for 7+ media.

**Step 13: Extensions.** For each active extension, fill the corresponding template section (13-16) completely using the extension-specific derivation procedure from the synthesis method.

**Step 14: QA.** ~40-60 tests (core + extension tests). Binary pass/fail. ID, severity, method. Test runner spec with weighted scoring.

**Step 15: Cross-validate.** Run all coherence checks from synthesis method Phase 5. Fix any failures before output.

### Output Requirements

**File 1: `design-system-spec.yaml`** — Valid, parseable YAML. 700-2000 lines. Every field populated with concrete values (real hex codes, real pixel values, real curves). No placeholders. No TODOs.

**File 2: `IMPLEMENTATION.md`** — Use the template in `references/06-implementation-template.md`. 500-1500 lines. Includes: philosophical foundation, spec navigation guide, medium-specific recipes, component selection tree, self-audit protocol, common mistakes, quality metrics, and closing thought. If extensions are active, include extension-specific implementation sections.

### Quality Gate

The output passes if a second agent, given only the YAML and the implementation guide (no dossier, no synthesis method), could produce a web application, a Word document, a slide deck, and an HTML email that all look like they belong to the same design family — and that a design-literate human would judge as professional, cohesive, and aesthetically refined.
