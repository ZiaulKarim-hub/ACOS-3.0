# Quality Assurance Framework

## Table of Contents
1. Core Checklist (40 tests)
2. Extension Checklists (8 modules, ~5 tests each)
3. Test Runner Specification
4. Scoring Model
5. Compliance Report Schema

---

## 1. CORE CHECKLIST

Every test is binary (pass/fail), deterministic, and assigned a severity: **critical** (blocks release, weighted 3×), **major** (must fix, 2×), or **minor** (should fix, 1×).

### Color (7 tests)
- **CLR-01** | All color values reference tokens, not raw hex | critical | Grep for hex patterns outside token definitions
- **CLR-02** | Text/background contrast meets WCAG 2.1 AA (4.5:1 normal, 3:1 large) | critical | Compute ratio per text element
- **CLR-03** | Interactive elements have 3:1 contrast against adjacent surfaces | critical
- **CLR-04** | Focus ring visible at 3:1 contrast on all backgrounds | critical
- **CLR-05** | Status colors correctly mapped (error=red, success=green, warning=yellow, info=blue) | major
- **CLR-06** | Theme tokens internally consistent (no cross-theme contamination) | critical
- **CLR-07** | Color never sole indicator of meaning | critical

### Typography (5 tests)
- **TYP-01** | All type uses specified typeface family | critical | Check computed font-family
- **TYP-02** | All type properties from defined tokens | critical | Match size/weight/height combos to token list
- **TYP-03** | Body text line length ≤ 75 characters | major
- **TYP-04** | Heading weight rules followed (≥20px: 300-400, <20px: 600) | major
- **TYP-05** | No orphaned single words on heading last lines (where controllable) | minor

### Spacing (4 tests)
- **SPC-01** | All spacing values match a defined token | critical
- **SPC-02** | Component internal spacing uses component-scale tokens | major
- **SPC-03** | Section separation uses layout-scale tokens | major
- **SPC-04** | No zero-spacing between adjacent elements (except within single component) | minor

### Grid (4 tests)
- **GRD-01** | All content aligns to column grid | critical | Overlay grid, verify edges
- **GRD-02** | Correct column counts at each breakpoint | critical
- **GRD-03** | No content placed in gutters | critical
- **GRD-04** | Grid mode consistent within each section | major

### Components (8 tests)
- **CMP-01** | All UI elements use system components, not recreations | critical
- **CMP-02** | Component size variant consistent within form/section | major
- **CMP-03** | Max 1 primary button per visible region | major
- **CMP-04** | All form inputs have visible labels | critical
- **CMP-05** | Error states show inline message + icon | critical
- **CMP-06** | Loading states use skeleton screens or spinners | major
- **CMP-07** | Modals trap focus and dismiss on Escape | critical
- **CMP-08** | Icon-only buttons have tooltip + aria-label | critical

### Accessibility (7 tests)
- **A11Y-01** | All interactive elements keyboard-accessible | critical | Tab traversal
- **A11Y-02** | Tab order matches visual order | critical
- **A11Y-03** | ARIA roles, labels, live regions correct | critical
- **A11Y-04** | prefers-reduced-motion honored | major
- **A11Y-05** | All images have meaningful alt text (or alt="" if decorative) | critical
- **A11Y-06** | Focus managed after dynamic content changes | critical
- **A11Y-07** | Touch targets ≥ 44×44px on mobile | critical

### Motion (3 tests)
- **MOT-01** | All transitions use system easing curves | major
- **MOT-02** | Duration matches element size (small=fast, large=slow) | minor
- **MOT-03** | Animations interruptible by user action | major

### Data Visualization (4 tests)
- **VIZ-01** | Chart colors follow categorical sequence in order | major
- **VIZ-02** | All charts have title, axis labels, legend | critical
- **VIZ-03** | No 3D chart effects | major
- **VIZ-04** | Tabular data alternative available for screen readers | critical

### Medium-Specific (6 tests)
- **DOC-01** | Document margins ≥ 1 inch | major
- **DOC-02** | Document body text 10-12pt in specified typeface | major
- **PRS-01** | Slide body text ≥ 18pt | critical
- **PRS-02** | No more than 6 bullet points per slide | major
- **EML-01** | Email layout max width 600px | critical
- **EML-02** | Email CSS fully inlined | critical

---

## 2. EXTENSION CHECKLISTS

Each extension adds 4-6 tests. Only active extensions are evaluated.

### Expressive Brand (EXP-*)
- **EXP-01** | Illustration style consistent across all instances | major
- **EXP-02** | Photography art direction follows defined rules | major
- **EXP-03** | Brand voice vocabulary uses preferred terms, avoids excluded terms | major
- **EXP-04** | Personality tokens (warmth, playfulness, etc.) reflected consistently across color, type, and illustration | major
- **EXP-05** | Gradient usage follows defined gradient tokens, not ad-hoc | major

### Motion & Interaction (INT-*)
- **INT-01** | All spring animations use defined physics presets | major
- **INT-02** | Gesture responses match vocabulary definition | critical
- **INT-03** | State machine transitions reference defined animation tokens | major
- **INT-04** | Haptic feedback patterns match defined triggers | major
- **INT-05** | Scroll effects degrade gracefully when prefers-reduced-motion is set | critical

### Spatial 3D (SPA-*)
- **SPA-01** | Materials reference defined material library | major
- **SPA-02** | Lighting setup matches specification | major
- **SPA-03** | Depth layers follow defined z-ordering | critical
- **SPA-04** | Spatial UI elements meet minimum interaction zone sizes | critical

### Cultural Traditions (CUL-*)
- **CUL-01** | Script-specific typefaces loaded for target languages | critical
- **CUL-02** | Cultural color semantics applied correctly for target locale | major
- **CUL-03** | RTL layout fully mirrored including component internals | critical
- **CUL-04** | Vertical text layout (if applicable) uses correct metrics | major

### Generative/Parametric (GEN-*)
- **GEN-01** | All generated outputs satisfy invariant constraints | critical
- **GEN-02** | Parameter values fall within defined min/max ranges | critical
- **GEN-03** | Same seed produces identical output (deterministic mode) | major
- **GEN-04** | Generated variations are visually recognizable as belonging to the same family | major

### Data-Dense (DEN-*)
- **DEN-01** | Micro-spacing tokens used (not standard tokens compressed) | major
- **DEN-02** | Component 2xs/xs sizes render readable text | critical
- **DEN-03** | Information density does not reduce contrast below WCAG thresholds | critical
- **DEN-04** | Keyboard shortcuts documented for all frequent actions | major

### Analog/Handcraft (ANA-*)
- **ANA-01** | Texture overlays do not reduce text contrast below WCAG thresholds | critical
- **ANA-02** | Imperfection rules produce consistent variation (not random noise) | major
- **ANA-03** | Hand-drawn icon variants maintain recognizability | major
- **ANA-04** | Process colors render correctly in both RGB and CMYK | major

### Adaptive Systems (ADP-*)
- **ADP-01** | Contextual overrides are documented with trigger conditions | major
- **ADP-02** | No two overrides produce contradictory results | critical
- **ADP-03** | Default (non-overridden) state is a complete, coherent system | critical
- **ADP-04** | Override transitions do not produce jarring visual changes | major

---

## 3. TEST RUNNER SPECIFICATION

**Input:** Path to artifact under test (URL, file path, or markup string) + list of active extensions.

**Execution:** Iterate all core checklist tests. For each active extension, iterate its checklist. For each test, execute the specified method, record pass/fail/skip with evidence.

**Output format:** JSON.

```json
{
  "artifact_path": "string",
  "timestamp": "ISO 8601",
  "extensions_tested": ["string"],
  "total_tests": 0,
  "passed": 0,
  "failed": 0,
  "skipped": 0,
  "compliance_score": 0.0,
  "results": [
    {
      "test_id": "CLR-01",
      "status": "pass | fail | skip",
      "severity": "critical | major | minor",
      "message": "detail if failed",
      "evidence": "extracted value or location"
    }
  ],
  "severity_breakdown": {
    "critical": { "passed": 0, "failed": 0 },
    "major": { "passed": 0, "failed": 0 },
    "minor": { "passed": 0, "failed": 0 }
  }
}
```

---

## 4. SCORING MODEL

**Weights:** critical = 3, major = 2, minor = 1.

**Formula:** `score = weighted_passed / weighted_total`

**Cap:** Any failed critical test caps the maximum score at 0.70.

**Thresholds:** excellent ≥ 0.95, good ≥ 0.85, acceptable ≥ 0.70, failing < 0.70.

---

## 5. COMPLIANCE REPORT

The compliance report is the test runner's output JSON plus a summary section:

```json
{
  "summary": {
    "score": 0.0,
    "grade": "excellent | good | acceptable | failing",
    "critical_failures": ["list of failed critical test IDs"],
    "recommendations": ["prioritized list of fixes"]
  }
}
```

Recommendations are ordered: critical failures first, then major, then minor. Each recommendation cites the test ID, the specific failing evidence, and the spec section that defines the correct value.
