# Implementation Guide Template

Use this template to write the `IMPLEMENTATION.md` output file. Fill every section. If extensions are active, include the extension implementation sections at the end.

---

## Required Sections

### 1. Philosophical Foundation (200-400 words)
Connect the design influences to the system's aesthetic identity. Frame them as operating principles, not historical footnotes. Explain WHY the system looks and feels the way it does — what tradition it descends from and what it aspires to be.

### 2. How to Read the Spec (table + 2 paragraphs)
Quick-reference table mapping the YAML sections to what they govern. Explain the token resolution order: medium constraints → theme → component token → core token → palette. Explain how extensions modify the base system.

### 3. Medium-Specific Recipes (one subsection per medium)
For each active medium, provide a concrete implementation skeleton. Required media and their recipe contents:

**Web Application:** Framework setup snippet (React/Angular/Vue), UI shell skeleton, component import pattern, theme provider configuration.

**Mobile Application:** Token-to-platform-unit mapping (px→dp for Android, px→pt for iOS), minimum touch target sizes, navigation pattern, safe area handling.

**Desktop Application:** Window chrome rules, keyboard shortcut framework, density toggle implementation, frameless window header pattern.

**Document (DOCX/PDF):** Type token-to-print-point mapping table, margin specifications in DXA/mm, heading hierarchy, color mapping for print (grayscale + one accent).

**Presentation (PPTX):** Grid-to-slide mapping (columns to inches), type minimum sizes for projection, slide layout templates (title, section, content, data, closing), color rules for light/dark slides.

**Documentary Presentation:** Structure template (cover → TOC → executive summary → body → appendix → back cover), type hierarchy, data visualization placement rules, white space requirements.

**Email:** Table-based layout skeleton (600px max width), inline CSS pattern, button VML fallback, font fallback strategy.

**Extension media** (if active): AR/VR/XR setup, terminal/CLI formatting, large-format print specifications.

### 4. Component Selection Decision Tree (table, ≥15 entries)
Format: "When you need X → Use Y → Not Z → Because [rationale]"

Cover: binary toggle vs checkbox, dropdown vs radio group, modal vs notification, tabs vs content-switcher, accordion vs tree-view, toast vs inline notification, data table vs structured list, search vs combo-box, tag vs badge, tile vs card, link vs button, popover vs tooltip, progress bar vs loading spinner, and any extension-specific decisions.

### 5. Agent Self-Audit Protocol (6 steps, 3-4 checks each)
Step 1: Structure Check (grid alignment, heading hierarchy, line length).
Step 2: Color Check (token usage, contrast ratios, color-not-sole-indicator).
Step 3: Component Check (button hierarchy, label presence, state coverage).
Step 4: Spacing Check (token adherence, vertical rhythm, white space).
Step 5: Accessibility Check (keyboard nav, alt text, ARIA, reduced motion).
Step 6: Medium Check (medium-specific constraints, typeface, sizes).

If extensions are active, add:
Step 7: Extension Check (personality consistency, motion-component alignment, cultural appropriateness, generative reproducibility).

### 6. Common Mistakes (≥10 entries, including extension-specific if active)
Format each as: "The mistake → Why it's wrong → The fix"

Core mistakes: wrong gray for print, arbitrary border-radius, drop shadows on flat components, multiple primary buttons, missing skeleton states, content in gutter, decorative motion, ignoring RTL.

Extension mistakes (include if active):
- Expressive: illustration style inconsistency across pages
- Motion: animations that cannot be interrupted
- Data-dense: using standard component heights in compact UI
- Cultural: Western color semantics applied to non-Western audience
- Generative: outputs that violate invariant constraints
- Analog: textures that reduce readability below WCAG thresholds
- Adaptive: contextual overrides that contradict each other

### 7. Quality Metrics (table)
5-7 quality axes with percentage weights. Include extension axes if active. Target compliance score. Reference the test runner spec.

### 8. Closing Thought (1 paragraph)
Frame constraint as creative liberation. Reference the design masters who inspired the system. End with a statement that connects precision execution to aesthetic excellence.
