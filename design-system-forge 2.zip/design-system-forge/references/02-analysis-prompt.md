# Design Analysis Prompt — Visual Autopsy & Influence Identification

## Table of Contents
1. Phase 1: Visual Autopsy (8 dimensions + 4 extension dimensions)
2. Phase 2: Influence Identification (12 investigation categories)
3. Phase 3: Influence Ranking & Contribution Mapping
4. Phase 4: Canonical Dossier Structure
5. Phase 5: Self-Validation

---

## PHASE 1: VISUAL AUTOPSY

Examine the provided sample(s) and answer EVERY question below with specific, concrete observations. For URLs, fetch the page. For images, analyze composition directly. For documents, examine layout, type, and structural hierarchy.

### 1.1 Typography
- Typeface family for body text? (Identify by name via web search if needed, or classify: humanist sans, geometric sans, neo-grotesque, transitional serif, slab, monospace, display, handwritten)
- Typeface for headings — same family or different?
- Typeface for code/monospace contexts?
- Approximate body text size (px)?
- Visible font weights? (Thin/Light/Regular/Medium/Semibold/Bold/Black)
- Text alignment? (flush-left/ragged-right, centered, justified, mixed)
- Heading size range (smallest to largest display)?
- Is there a visible mathematical type scale or arbitrary sizing?
- Line-height ratio for body text? (tight ~1.2, standard ~1.4, loose ~1.6)
- Letter-spacing adjustments at different sizes?
- Are there decorative, hand-drawn, or script typefaces present?
- Is vertical text used (CJK, rotated labels)?
- Are there typographic treatments beyond plain text (outlined, shadowed, overlapping, masked by images)?

### 1.2 Color
- Primary background color? (Hex if determinable)
- Primary text color?
- Primary interactive/accent color?
- Total distinct hue families visible? List each.
- Evidence of graded palette (multiple lightness steps per hue)?
- Status/feedback colors? (error, success, warning, info)
- Overall palette temperature? (warm/cool/neutral)
- Dark mode or alternate theme visible?
- Color restraint level? (monochromatic+accent / limited / rich / maximal)
- Is color used emotionally/expressively or purely functionally?
- Are there gradients? If so, what kind? (linear, radial, mesh, angular)
- Is there evidence of cultural color symbolism? (e.g., red = luck/prosperity, white = mourning)

### 1.3 Grid and Layout
- Visible column grid? Column count at widest viewport?
- Approximate gutter width?
- Layout type? (full-width fluid / max-width centered / hybrid)
- Observable breakpoints (px)?
- Composition: symmetric or asymmetric?
- Content alignment: strict grid or freely positioned?
- Approximate page margins?
- Are there non-grid layouts present? (radial, overlapping, broken-grid, collage, stacked)
- Are there full-bleed elements that break the grid intentionally?

### 1.4 Spacing
- Systematic or organic spacing?
- Smallest visible spacing unit (px)?
- Largest visible spacing unit (px)?
- Base unit multiple? (4px / 5px / 8px / 10px / unclear)
- Is spacing extremely tight (data-dense) or extremely generous (editorial)?

### 1.5 Iconography
- Icon style? (outlined/stroked, filled, duotone, illustrated, 3D)
- In-component icon size?
- Larger illustrative graphics present? Style?
- Icon geometry: geometric / organic / rounded / angular / hand-drawn?

### 1.6 Components
- Visible UI components? (List all observed)
- Button styles? (filled, outlined, ghost, rounded corners, sharp, pill-shaped)
- Approximate default component height?
- Multiple component sizes?
- Visible interactive states? (hover, focus rings, active, disabled)
- Component density: spacious, standard, or compact?

### 1.7 Motion and Interaction (live sites only)
- Are transitions/animations present?
- Speed and character? (snappy, smooth, springy, dramatic, subtle)
- Functional (state change) or decorative (visual interest)?
- Micro-interactions? (hover reveals, expanding, loading indicators)
- Scroll-driven effects? (parallax, reveal-on-scroll, sticky elements)
- Does motion feel physics-based (spring/bounce) or tween-based (linear/ease)?

### 1.8 Overall Aesthetic Character
Describe in 3-5 adjectives. Then classify along each axis:
- Clinical/technical ←→ Warm/human
- Dense/information-heavy ←→ Spacious/editorial
- Traditional/conservative ←→ Modern/progressive
- Playful ←→ Serious
- Engineered precision ←→ Creative expression
- Rational/systematic ←→ Organic/intuitive

### 1.9 Extension Dimensions (answer if applicable)

**Expressive/Brand:** Are illustrations present? What style? Is photography art-directed? Does the design have a perceptible "personality"? Could you describe the brand voice from the visual language alone?

**Spatial/3D:** Is there real depth beyond flat layers? Perspective? Lighting? Material textures (glass, metal, fabric)? Does the UI exist in 3D space?

**Generative/Parametric:** Do visual elements show algorithmic variation? Are identity marks unique per instance? Do patterns appear generated rather than hand-placed?

**Analog/Handcraft:** Are textures, grain, or noise present? Hand-drawn elements? Deliberate imperfection? Print-craft aesthetics (letterpress, risograph, woodblock)?

---

## PHASE 2: INFLUENCE IDENTIFICATION

For each candidate influence, establish: (1) specific visual connection to Phase 1 observations, (2) historical basis, (3) design principles, (4) what to extract for synthesis.

### Investigation Categories

**A. Typographic Movements**
- International Typographic Style / Swiss Style (1950s–1960s)
- The New Typography / Jan Tschichold (1928)
- Bauhaus typographic tradition (1919–1933)
- Post-modern / deconstructivist typography (1980s–1990s: Carson, Emigre, Cranbrook)
- Contemporary humanist type design (2000s–2020s)
- CJK typographic traditions (Chinese, Japanese, Korean — if applicable)
- Arabic/Persian calligraphic traditions (if applicable)
- Indic script traditions (Devanagari, Tamil, etc. — if applicable)

**B. Grid and Layout Traditions**
- Müller-Brockmann's modular grid
- De Stijl / Neoplasticism
- Marber Grid (Penguin, 1961)
- Responsive/fluid grids (Marcotte, 2010s)
- 8-point grid system
- Broken-grid / anti-grid (Weingart, Carson, 1980s–90s)
- Japanese Ma (negative space as compositional force)
- Organic/radial layout traditions

**C. Color Theory and Application**
- Albers' Interaction of Color (1963)
- Bauhaus color theory (Itten, Kandinsky)
- De Stijl chromatic restriction
- WCAG accessibility-driven color
- Token-based color systems (design tokens movement)
- Cultural color systems (Chinese five-element, Indian color symbolism, etc.)
- Process color / print color traditions (CMYK, spot color)

**D. Industrial Design Philosophy**
- Dieter Rams / Ten Principles (1970s)
- Bauhaus "form follows function"
- Scandinavian design / Nordic minimalism
- Japanese design / Muji / Kenya Hara / Wabi-sabi
- Memphis Group / post-modern maximalism (1980s)
- Arts and Crafts movement (Morris, 1880s–1910s)

**E. Corporate Identity and Wayfinding**
- Otl Aicher / Munich Olympics 1972
- Massimo Vignelli / NYC Transit, Unimark
- Wim Crouwel / Total Design
- NASA Graphics Standards (Danne & Blackburn, 1975)
- Lufthansa identity (Aicher)
- Contemporary flexible identity systems (MIT Media Lab, Nordkyn, etc.)

**F. Digital Design Systems**
- Atomic Design (Brad Frost, 2013)
- Design tokens (Salesforce Lightning, W3C Design Tokens CG)
- Material Design (Google, 2014)
- Fluent Design (Microsoft, 2017)
- Human Interface Guidelines (Apple, 1987–present)
- Ant Design, Chakra UI, Tailwind (2020s ecosystem)

**G. Accessibility and Standards**
- WCAG 2.x (W3C)
- Section 508
- ISO 7010 (safety symbols)
- EN 301 549 (European accessibility)

**H. Data Visualization**
- Edward Tufte (data-ink ratio, small multiples)
- Jacques Bertin (Semiology of Graphics, 1967)
- Contemporary data viz (D3, Observable, Vega-Lite)

**I. Business Communication Standards**
- Chicago Manual of Style
- Corporate report conventions
- ISO 216 paper sizes

**J. Art Movements**
- Russian Constructivism (1920s)
- De Stijl (1917–1931)
- Minimalism / Hard-edge painting (1960s)
- Concrete Art (Max Bill)
- Pop Art (Warhol, 1960s — if expressive)
- Psychedelic / countercultural graphics (1960s–70s)
- Punk / zine aesthetics (1970s–80s)
- Vaporwave / digital nostalgia (2010s)

**K. Motion and Interaction Traditions (if applicable)**
- Saul Bass title sequences (1950s–1990s)
- Motion graphics / MoGraph tradition (1990s–present)
- Physics-based UI (iOS 7+, Material motion)
- Choreographic design (Rachel Nabors, Sarah Drasner)
- Game UI traditions (HUD design, real-time feedback)

**L. Craft and Material Traditions (if applicable)**
- Letterpress / typographic printing
- Risograph / zine culture
- Woodblock printing (Japanese ukiyo-e influence)
- Textile patterns / woven design
- Architectural drafting / blueprint aesthetics

**Constraint:** Never include the sample's own creator/organization as an influence. Trace lineage further back.

---

## PHASE 3: INFLUENCE RANKING & CONTRIBUTION MAPPING

Rank each identified influence as:
- **●●●** Primary — the sample would not exist without this
- **●●○** Strong secondary — meaningful contribution to 1-2 categories
- **●○○** Minor — detectable but not defining
- **○○○** Not present

Build the contribution matrix with ALL columns:

```
| Influence | Grid | Type | Color | Spacing | Motion | Icons | Components | Data Viz | Illustration | Voice | Philosophy |
```

The additional columns (Illustration, Voice) accommodate expressive systems. If the sample is purely rationalist, mark those columns ○○○ for all influences.

---

## PHASE 4: CANONICAL DOSSIER STRUCTURE

Output exactly one file: `design-influences-research.md`

Structure:

```markdown
# Design Influences Research Dossier

**Purpose:** [1 paragraph]
**Sample analyzed:** [URL/description of input]
**Analysis date:** [ISO date]
**Extensions activated:** [list of extension IDs triggered by Phase 1 observations]

---

## Influence N: [Name] ([Decade range])

**Origin:** [Where, when, key schools/movements]

**Key Practitioners:**
- **[Name]** — [1 sentence, key work cited]

**Principles to Extract:**
1. [Actionable principle]

**What to synthesize:** [1 paragraph mapping to design system categories:
grid, typography, color, spacing, motion, iconography, components, patterns,
data visualization, illustration, photography, voice, globals/principles]

---

## Summary Matrix

[Full contribution matrix from Phase 3]
```

Include **8 to 16 influences** depending on complexity. Each entry: **150-400 words**.

---

## PHASE 5: SELF-VALIDATION

Before delivering, verify:

1. **Traceability:** Each influence has ≥2 specific Phase 1 observations supporting it.
2. **Coverage:** All 11+ design categories are explained by the combined influences (grid, type, color, spacing, motion, icons, components, data viz, illustration, voice, philosophy). If any category is unexplained, search for additional influences.
3. **Non-redundancy:** No two influences cover identical ground. Differentiate or merge.
4. **Downstream compatibility:** The synthesis-instructions document can use this dossier, unmodified, to derive values for every template section. If extensions were activated, the dossier must include influences that inform those extension sections.
5. **Historical accuracy:** All names, dates, attributions verified via web search.
6. **Cultural sensitivity:** Non-Western influences are treated with equal depth and respect as Western ones, not reduced to stereotypes or footnotes.
