# Synthesis Method — From Influences to Concrete Values

## Table of Contents
1. The Synthesis Problem
2. Phase 1: Extract Invariants
3. Phase 2: Assign Influence Primacy
4. Phase 3: Derive Concrete Values (10 derivation procedures)
5. Phase 4: Extension-Aware Derivation
6. Phase 5: Cross-Validate for Coherence
7. Phase 6: Write Globals
8. Phase 7: Quality Control Authoring
9. Anti-Patterns

---

## 1. THE SYNTHESIS PROBLEM

You have a set of identified design influences. Each contributes something essential, but they were never designed to work together. Your task is to produce a unified system where every element shares a common DNA — where the grid, type, color, spacing, motion, and components feel like natural expressions of the same aesthetic intelligence.

A synthesis dissolves influences into something new. It is not a collage (things placed side by side), not an average (splitting differences), and not a recreation (historical reproduction).

---

## 2. PHASE 1: EXTRACT INVARIANTS

Read every influence in the dossier. Identify what the primary influences ALL agree on. These become your non-negotiable foundations.

**Common invariant patterns by system archetype:**

For **rationalist** systems (Swiss-lineage): Grid sovereignty, sans-serif default, restraint, structural hierarchy, accessibility as baseline.

For **expressive** systems (brand-forward): Personality coherence, emotional color logic, illustration-text integration, voice consistency, strategic rule-breaking.

For **data-dense** systems (professional tools): Information density optimization, micro-typography, minimal chrome, expert-user assumptions, speed of comprehension.

For **culturally-specific** systems: Script-appropriate typography, cultural color semantics, directionality-first layout, locale-aware component behavior.

For **generative** systems: Parametric range definitions, invariant constraints (what MUST stay the same), variation axes (what CAN change), seed reproducibility.

Write invariants into `meta.philosophy` and `globals.design_principles`.

---

## 3. PHASE 2: ASSIGN INFLUENCE PRIMACY

Using the contribution matrix from the influence dossier, assign a primary and secondary influence to each template section. The primary influence is consulted first for derivation; the secondary fills gaps.

**Extended primacy table (fill based on your specific dossier):**

| System Category | Typical Primary | Typical Secondary |
|----------------|----------------|-------------------|
| Grid | Swiss Style / 8pt grid | De Stijl, responsive grids |
| Typography | Swiss Style / Tschichold | Humanist type design, cultural scripts |
| Color | Albers / WCAG / tokens | Bauhaus, cultural color systems |
| Spacing | Vignelli / tokens | Swiss Style |
| Motion | Rams / iOS physics | Saul Bass, choreographic design |
| Iconography | Aicher (Munich '72) | ISO 7010, Rams |
| Components | Atomic Design / Rams | WCAG, platform HIG |
| Data Viz | Tufte | Bertin, Aicher |
| Illustration | (varies by sample) | Pop Art, Memphis, Arts & Crafts |
| Photography | (varies by sample) | Documentary tradition, editorial |
| Voice/Personality | (varies by sample) | Brand strategy literature |
| Globals | Rams (10 Principles) / Vignelli (Canon) | All others |

---

## 4. PHASE 3: DERIVE CONCRETE VALUES

### 3.1 Grid Derivation
1. Base unit: **8px** (retina-friendly). Override to 4px for data-dense systems.
2. Columns: **16** for maximum flexibility (12 acceptable for simpler systems).
3. Gutters: 32px standard, 16px narrow, 1px condensed (0px for data-dense).
4. Breakpoints: test at 0, 672, 1056, 1312, 1584 px. Map columns: 4→8→16→16→16.
5. If the sample uses non-grid layouts, additionally define `grid.non_grid_layouts` with the observed compositional rules (radial center, overlap z-order, free-form bounding boxes).

### 3.2 Typography Derivation
1. Select ONE primary sans-serif family. Must have: Regular (400), Medium (500), Semibold (600). Should have: Light (300), Bold (700). Must have monospace companion.
2. If cultural extension is active, add script-specific families (e.g., Noto Sans CJK, Noto Naskh Arabic) with the same weight range where available.
3. Build 15-step scale: 12, 14, 16, 18, 20, 24, 28, 32, 36, 42, 48, 54, 60, 68, 76. For data-dense, prepend: 10, 11.
4. Compose ~25 tokens. Line-height: ×1.4 body, ×1.25 heading, ×1.2 display. Letter-spacing: +0.32px at 12px, +0.16px at 14px, 0 at 16px+, -0.01em at 42px+.
5. For expressive systems, add display/decorative tokens using the secondary typeface at the top of the scale (48px+).

### 3.3 Color Derivation
1. Neutral palette: 10 grades (grade-10 through grade-100), near-white to near-black.
2. Primary family: 10 grades. Blue is most common for rationalist; choose based on sample.
3. 4-6 supporting families: include semantic (red=error, green=success, yellow=warning, blue=info).
4. For each grade, test contrast against both light and dark theme backgrounds. Mark text-safe grades.
5. Build 4 themes: White, Light-gray, Dark-gray, Near-black. Map ~50-60 role tokens.
6. For expressive systems, add gradient tokens: `{start_hex, end_hex, angle, type}`.
7. For cultural extension, add `color.cultural_semantics` mapping.

### 3.4 Spacing Derivation
1. Component scale (13 steps): 2, 4, 8, 12, 16, 24, 32, 40, 48, 64, 80, 96, 160 px.
2. Layout scale (7 steps): 16, 24, 32, 48, 64, 96, 160 px.
3. For data-dense extension, add micro scale: 1, 2, 3, 4, 6 px.
4. For expressive/editorial systems, extend layout scale upward: 192, 240, 320 px for dramatic white space.

### 3.5 Motion Derivation
1. Two personalities: Productive (task) and Expressive (narrative).
2. Each gets 3 cubic-bezier curves: standard, entrance, exit.
3. Duration scale: 70, 110, 150, 240, 400, 700 ms.
4. If motion-interaction extension is active, additionally define spring physics presets: `{tension, friction, mass}` for bouncy, snappy, gentle, and heavy variants.
5. If motion-interaction extension is active, define gesture vocabulary and state machines.
6. Always specify reduced-motion policy.

### 3.6 Iconography Derivation
1. UI icons: 16, 20, 24, 32 px. Default: 16px. 10 functional categories.
2. Pictograms: 32, 48, 64, 80 px. Default: 64px. Editorial use.
3. If analog-handcraft extension is active, define hand-drawn icon style rules (stroke variation, imperfect geometry, organic curves).

### 3.7 Component Derivation
1. Inventory: ≥35 components across 8 subcategories.
2. Each component: id, variants, sizes (sm/md/lg → 32/40/48px), states (enabled, hover, active, focus, disabled, error, read-only), anatomy (named parts), rules.
3. For data-dense extension, add 2xs (20px) and xs (24px) size tiers.
4. If motion-interaction extension is active, add `behavior` field to each component specifying gesture responses and state transitions.

### 3.8 Pattern Derivation
1. ≥10 patterns: global-header, login, empty-states, filtering, forms, loading, notifications, dialogs, overflow-content, status-indicators.
2. For each pattern, list components used and layout rules.

### 3.9 Data Visualization Derivation
1. ≥12 chart types with variants.
2. Categorical color sequence: 12-14 ordered colors drawn from palette families at consistent grades.
3. Rules for titles, labels, legends, accessibility, no 3D effects.

### 3.10 Globals Derivation
1. 5-7 design principles synthesized from invariants.
2. Layer/depth model. Focus model. Responsive strategy. RTL rules.
3. Medium-specific variables for 7+ media (web, mobile, desktop, document, presentation, documentary presentation, email, plus any extensions like AR/VR, terminal, large-format print).

---

## 5. PHASE 4: EXTENSION-AWARE DERIVATION

When extensions are active, perform these additional derivation steps:

**Expressive-brand:** Derive illustration style descriptors, photography art direction rules, personality tokens (warmth/playfulness/energy/formality/density on 0-10 scales), and brand voice vocabulary. Source these from the Phase 1 observations and the dossier's expressive-tradition influences.

**Motion-interaction:** Derive spring physics presets by observing the sample's animation character. Snappy = high tension + high friction. Bouncy = high tension + low friction. Gentle = low tension + moderate friction. Define gesture vocabulary from observed interactions. Build state machines for complex components (e.g., swipe-to-delete: idle → swiping → threshold-reached → action-confirmed → dismissed).

**Spatial-3d:** Derive material properties, lighting setup, and depth layers from the sample's visual depth cues. Map to target platform conventions (visionOS materials, WebXR lighting).

**Cultural-traditions:** Derive script-specific typography adjustments, cultural color semantics, and layout direction rules from the dossier's cultural influences and the sample's observed language/script.

**Generative-parametric:** Derive parameter ranges, invariant constraints, variation axes, and seed strategy from the sample's observed generative patterns. Specify what stays constant and what varies per instance.

**Data-dense:** Derive micro-spacing scale, ultra-compact component sizes, micro-typography tokens, and density-appropriate color contrast thresholds (may need to exceed WCAG AA due to expert-user context).

**Analog-handcraft:** Derive texture library, imperfection rules (e.g., stroke-width variation ±0.5px, rotation jitter ±1°), and process-color palette (slightly impure colors that reference CMYK printing).

**Adaptive-systems:** Derive contextual override rules — conditions under which the base specification changes (e.g., "when content is legal text, switch to serif typeface and increase line-height to 1.6"). Document the decision tree for each override.

---

## 6. PHASE 5: CROSS-VALIDATE FOR COHERENCE

Run these checks after filling all sections:

1. **Grid-Type Alignment:** Every type token's line-height should be a multiple of the base unit (8px) or within 2px.
2. **Spacing-Grid Harmony:** Every spacing token is a multiple of the base unit.
3. **Color-Accessibility Sweep:** Every text-token + background-token pair meets WCAG contrast thresholds.
4. **Component-Token Fidelity:** Every component visual property resolves to a token. Zero raw values.
5. **Medium Portability:** Tokens can be resolved to every target medium's native units.
6. **Extension Coherence:** If extensions are active, their values use the same palette, scale, and grid as the core system. They extend, not contradict.
7. **Personality Consistency** (expressive extension): The personality tokens (warmth, playfulness, etc.) are reflected in every category — color warmth matches illustration warmth matches voice warmth.
8. **Motion-Component Alignment** (motion extension): Every component behavior references a defined spring preset or easing curve. No ad-hoc animation values.

---

## 7. PHASE 6: WRITE GLOBALS

Derive from the invariants and primary influences. The globals are meta-rules governing relationships between all categories.

Typical structure: 5-7 design principles, layer model, focus model, responsive strategy, RTL rules, and 7+ medium-specific variable blocks.

---

## 8. PHASE 7: QUALITY CONTROL AUTHORING

Every rule in the system must have a corresponding test. Each test specifies id, declarative test statement, severity (critical/major/minor), and testing method. Extension-activated sections must also have tests.

See `references/07-qa-framework.md` for the complete test authoring guide.

---

## 9. ANTI-PATTERNS

1. **Averaging:** Do not split differences between conflicting influences. Evaluate and choose.
2. **Cherry-picking aesthetics:** Do not isolate visual layers. Derive each from first principles.
3. **Historical recreation:** You are making a modern system informed by history, not a period piece.
4. **Maximalism:** If you are adding more options, more variants, more tokens — stop. Less, but better.
5. **Western-default bias:** If cultural extensions are active, the non-Western tradition is not a footnote; it is a co-equal design force that shapes the entire system.
6. **Motion-as-afterthought:** If the motion extension is active, motion is not cosmetic; it is structural — as fundamental as color or type.
7. **Token-washing:** Wrapping arbitrary values in token names does not make them systematic. Every token must derive from the scale, the grid, or the palette. No orphan values.
