# Influence Catalog — Reference Encyclopedia

## Table of Contents
1. Typographic Movements (8 entries)
2. Grid and Layout Traditions (8 entries)
3. Color Theory (6 entries)
4. Industrial Design Philosophy (6 entries)
5. Corporate Identity Systems (6 entries)
6. Digital Design Systems (6 entries)
7. Accessibility Standards (4 entries)
8. Data Visualization (3 entries)
9. Art Movements (8 entries)
10. Motion Traditions (5 entries)
11. Craft & Material Traditions (5 entries)
12. Cultural Design Traditions (6 entries)

Each entry provides: period, origin, key practitioners, visual signature, and what it contributes to a design system.

---

## 1. TYPOGRAPHIC MOVEMENTS

### 1.1 International Typographic Style (1950s–1960s)
**Origin:** Zürich and Basel, Switzerland. **Practitioners:** Josef Müller-Brockmann, Armin Hofmann, Emil Ruder, Max Bill, Karl Gerstner. **Visual signature:** Sans-serif type (Helvetica, Univers), flush-left ragged-right alignment, mathematical type scales, objective photography over illustration. **Contributes:** Type token structure, flush-left default, restricted typeface selection, the philosophy that typography serves communication.

### 1.2 The New Typography (1928)
**Origin:** Germany. Jan Tschichold's *Die Neue Typographie*. **Practitioners:** Tschichold, El Lissitzky, Herbert Bayer. **Visual signature:** Asymmetric layout, sans-serif primacy, photography over illustration, standardized paper sizes. **Contributes:** The foundational argument for asymmetric, sans-serif, flush-left typography as the modern default. The standardization impulse that underpins design systems as standards documents.

### 1.3 Bauhaus Typography (1919–1933)
**Origin:** Weimar/Dessau/Berlin. **Practitioners:** Herbert Bayer (universal typeface), László Moholy-Nagy (photo-typography), Josef Albers. **Visual signature:** Geometric construction, lowercase advocacy, integration of type and image as unified composition. **Contributes:** The principle that visual elements are governed by rules not taste. Reproducibility as a design requirement.

### 1.4 Post-Modern / Deconstructivist Typography (1980s–1990s)
**Origin:** Cranbrook Academy, Emigre magazine, CalArts. **Practitioners:** David Carson, Neville Brody, Rudy VanderLans, Ed Fella, April Greiman. **Visual signature:** Layered type, broken grids, mixed typefaces, illegibility as intentional provocation, visual noise as expressive tool. **Contributes (for expressive systems):** Permission to break the grid deliberately, typography as self-expression, layering and collision as compositional strategies.

### 1.5 Contemporary Humanist Type Design (2000s–2020s)
**Origin:** Global. **Practitioners:** Erik Spiekermann (FF Meta), Lucas de Groot (Calibri/TheSans), Bold Monday, Dalton Maag, Google Fonts. **Visual signature:** Warm, open forms optimized for screen reading at small sizes; large x-heights; clear distinction between similar letterforms (I/l/1). **Contributes:** Accessibility-first type selection; the principle that a typeface should be optimized for its primary medium (screen).

### 1.6 CJK Typographic Traditions
**Origin:** China, Japan, Korea. **Practitioners:** Akira Kobayashi, Ryuichi Sakamoto (design context), Toppan Printing, Morisawa. **Visual signature:** Monospaced CJK characters in a square em-box; vertical text capability; complex stroke structures requiring larger minimum sizes; mixed-script challenges (CJK + Latin). **Contributes:** Vertical text layout tokens, larger minimum text sizes for CJK, mixed-script spacing rules, square-em grid alignment.

### 1.7 Arabic/Persian Calligraphic Traditions
**Origin:** Middle East, North Africa, Central Asia. **Practitioners:** Hassan Massoudy, Mamoun Sakkal, Tarek Atrissi. **Visual signature:** Right-to-left flow, connected cursive letterforms, calligraphic variation (Naskh, Nastaliq, Kufic), diacritical marks above and below baseline. **Contributes:** RTL-first layout architecture, calligraphic display type tokens, expanded vertical metrics, bidirectional content mixing rules.

### 1.8 Indic Script Traditions
**Origin:** South Asia. **Practitioners:** Various foundries (Indian Type Foundry, Ek Type). **Visual signature:** Complex conjunct characters, headline bar (Shirorekha in Devanagari), diverse scripts (Devanagari, Tamil, Bengali, Gurmukhi, etc.). **Contributes:** Script-specific line-height and spacing adjustments, complex text shaping requirements, larger minimum sizes.

---

## 2. GRID AND LAYOUT TRADITIONS

### 2.1 Müller-Brockmann's Modular Grid
**Text:** *Grid Systems in Graphic Design* (1981). **Signature:** Multi-column grids with mathematical proportions, modular subdivision, consistent margins. **Contributes:** The 16-column grid, gutter ratios, the principle that grid is "the basic structure."

### 2.2 De Stijl / Neoplasticism (1917–1931)
**Practitioners:** Mondrian, van Doesburg. **Signature:** Horizontal/vertical lines only, primary colors + B/W, asymmetric balance. **Contributes:** Chromatic restriction discipline, proportional asymmetry, the grid as spiritual truth.

### 2.3 Marber Grid (1961)
**Origin:** Romek Marber for Penguin Books. **Signature:** A rigid three-part grid for book covers that produced visual variety, not monotony. **Contributes:** Proof that constraint produces diversity. The template concept — same structure, different content.

### 2.4 Responsive/Fluid Grids (2010s)
**Origin:** Ethan Marcotte's "Responsive Web Design" (2010). **Signature:** Fluid columns, breakpoint-based reflow, percentage-based widths. **Contributes:** Breakpoint definitions, column reflow rules, the principle of designing for the smallest screen first.

### 2.5 8-Point Grid System
**Origin:** Popularized by Bryn Jackson (Spec.fm) and Google Material. **Signature:** All dimensions and spacing in multiples of 8px. **Contributes:** The base unit for spacing and component sizing. Pixel-perfect alignment on all screen densities.

### 2.6 Broken Grid / Anti-Grid (1980s–90s)
**Practitioners:** Wolfgang Weingart, David Carson, April Greiman. **Signature:** Deliberately disrupted grids, overlapping elements, rotated text blocks. **Contributes (for expressive/analog systems):** Rules for intentional grid violation, overlap as compositional tool, rotation as hierarchy mechanism.

### 2.7 Japanese Ma (Negative Space)
**Origin:** Japanese aesthetic philosophy. **Signature:** Ma is not emptiness but "pregnant pause" — space charged with meaning. Space between elements is as composed as the elements themselves. **Contributes:** White space as active design element (not just "leftover"), compositional spacing that creates rhythm and breathing.

### 2.8 Organic/Radial Layouts
**Origin:** Various — Art Nouveau, dashboard/gauge design, spatial interfaces. **Signature:** Non-rectilinear arrangement, radial symmetry, curved paths. **Contributes (for spatial/non-standard systems):** Non-grid layout specification format, radial composition rules, curved content paths.

---

## 3. COLOR THEORY

### 3.1 Albers' Interaction of Color (1963)
**Principle:** Colors do not exist in isolation; they interact. The same color looks different against different backgrounds. **Contributes:** The rationale for token-based color (context-dependent values), theme-aware color mapping, contrast-as-relationship.

### 3.2 Bauhaus Color Theory (Itten, Kandinsky)
**Principle:** Johannes Itten's color contrasts (hue, value, temperature, complement, saturation, area). Kandinsky's color-form correspondence. **Contributes:** Systematic palette construction, the idea that each color has emotional/functional weight.

### 3.3 De Stijl Chromatic Restriction
**Principle:** Only primary colors (red, yellow, blue) plus black, white, gray. **Contributes:** The discipline of extreme palette restriction; the idea that fewer colors = stronger communication.

### 3.4 WCAG Accessibility-Driven Color
**Standard:** 4.5:1 contrast for normal text, 3:1 for large text (AA). **Contributes:** The non-negotiable floor for all color decisions. Contrast ratio as a design constraint, not an afterthought.

### 3.5 Token-Based Color Systems (2014+)
**Origin:** Salesforce Lightning Design System, W3C Design Tokens Community Group. **Contributes:** Color as named variable (not hex), multi-theme architecture, semantic color naming (role-based, not hue-based).

### 3.6 Cultural Color Systems
**Examples:** Chinese five-element colors (wood=green, fire=red, earth=yellow, metal=white, water=black); Indian festival colors; Islamic green; Western mourning black vs. East Asian mourning white. **Contributes (for cultural extension):** Color-meaning mappings that override Western defaults, locale-aware color token overrides.

---

## 4. INDUSTRIAL DESIGN PHILOSOPHY

### 4.1 Dieter Rams / Ten Principles (1970s)
**Motto:** "Weniger, aber besser" (Less, but better). **Contributes:** The ten principles as a decision test for every design element. Neutral palettes, rectilinear forms, clear control hierarchy, the idea that design should be "unobtrusive."

### 4.2 Bauhaus "Form Follows Function"
**Principle:** (Sullivan, adopted by Gropius). Standardization, mass-production compatibility, unity of art and technology. **Contributes:** Component standardization, the token system as mass-production tool.

### 4.3 Scandinavian / Nordic Minimalism (1950s–present)
**Practitioners:** Alvar Aalto, Arne Jacobsen, IKEA design team. **Signature:** Warm minimalism — natural materials, soft curves, light wood, functional beauty. **Contributes (for warm/humanist systems):** Warmth within restraint, soft corner radii, natural color palettes.

### 4.4 Japanese Design / Wabi-Sabi
**Practitioners:** Kenya Hara (Muji), Naoto Fukasawa, Sori Yanagi. **Signature:** Beauty in imperfection and impermanence, extreme simplicity, material honesty. **Contributes:** The philosophy that emptiness is not absence but presence; that imperfection can be intentional and beautiful.

### 4.5 Memphis Group (1980s)
**Practitioners:** Ettore Sottsass, Michele De Lucchi. **Signature:** Bold colors, geometric patterns, clashing materials, playful irreverence. **Contributes (for maximalist/expressive systems):** Permission for bold color, pattern as structural element, playfulness as legitimate design mode.

### 4.6 Arts and Crafts (Morris, 1880s–1910s)
**Practitioners:** William Morris, C.R. Ashbee. **Signature:** Handcraft virtue, rejection of industrial uniformity, ornamental pattern from nature. **Contributes (for analog-handcraft systems):** Texture as design element, handmade quality as value, pattern libraries derived from organic forms.

---

## 5. CORPORATE IDENTITY SYSTEMS

### 5.1 Massimo Vignelli / Unimark International (1960s–2000s)
**Origin:** Milan → New York. Unimark International (1965), then Vignelli Associates (1971). **Practitioners:** Massimo Vignelli, Bob Noorda, Ralph Eckerstrom. **Visual signature:** Helvetica as universal typeface, ruthless grid discipline, restricted color palettes, wayfinding systems built for millions of daily interactions. Key works: New York City Subway signage (1966–1970, with Noorda), American Airlines identity, Knoll graphics. **Contributes:** The corporate identity manual as genre (comprehensive, prescriptive, multi-touchpoint). The conviction that five typefaces are enough for a career. White space as active structural element. *The Vignelli Canon* (2009) as a design-decision framework covering semantics, syntactics, and pragmatics. The grid as "the basic structure of our graphic design."

### 5.2 Otl Aicher / Munich Olympics (1972)
**Origin:** Germany. Visual identity for the 1972 Munich Olympic Games. **Practitioners:** Otl Aicher, with the Department of Visuelle Kommunikation at HfG Ulm. **Visual signature:** 176 sport pictograms on a strict 20×20 grid, a systematic color palette (light blues, greens, silver, orange, white), total-design coverage from stadium banners to lapel pins. **Contributes:** The pictogram as precision communication tool — each symbol reducible to geometric essentials on a strict grid. Proof that one system can govern wildly diverse media (architecture, print, garments, signage, merchandise). Color palette as unifying identity across thousands of touchpoints.

### 5.3 Wim Crouwel / Total Design (1960s–1980s)
**Origin:** Amsterdam, The Netherlands. Total Design (now Total Identity), founded 1963. **Practitioners:** Wim Crouwel, Benno Wissing, Friso Kramer. **Visual signature:** Systematic, programmatic visual identity — every element derived from rules. The "New Alphabet" (1967): an experimental typeface built entirely on horizontal/vertical strokes, exploring machine-readable form. **Contributes:** Design as "programme" — a system of rules rather than individual decisions. The philosophical connection between machine logic and visual form, directly applicable to AI-generated design. Identity as algorithm.

### 5.4 NASA Graphics Standards Manual (1975)
**Origin:** United States. Designed by Richard Danne and Bruce Blackburn. **Visual signature:** The NASA logotype ("worm"), Helvetica throughout, a strict grid governing every application from Vehicle Assembly Building signage to letterhead, a masterclass in scale — the same identity legible at 2 inches and 200 feet. **Contributes:** Proof that a standards manual can govern artifacts across extreme scale ranges. The logotype as a flexible yet inviolable mark. Application rules that cover scenarios the designers never personally encountered — the mark of a truly systematic specification.

### 5.5 Lufthansa Identity (1962)
**Origin:** Germany. Designed by Otl Aicher and the HfG Ulm development group. **Visual signature:** The crane-in-circle mark, Helvetica, a yellow-and-blue palette, applied across aircraft livery, ticketing, airport signage, crew uniforms, in-flight materials, and corporate stationery. **Contributes:** One of the first truly comprehensive corporate identity programs. Demonstrated that a visual system could unify an entire corporation's touchpoints into a single recognizable presence. The identity manual as a binding contract between design and implementation.

### 5.6 Contemporary Flexible Identities (2000s–2020s)
**Origin:** Global. **Practitioners:** MIT Media Lab (Pentagram/Michael Bierut, 2010 — a generative algorithm producing unique marks per group), Nordkyn tourism identity (Neue Design Studio, 2007 — logo shape generated from live weather data), City of Melbourne (Landor, 2009 — a faceted M producing hundreds of variations). **Visual signature:** Identity marks that are systems rather than fixed symbols — algorithmic, data-driven, or modular, producing a family of related-but-unique outputs. **Contributes (for generative extension):** The concept that a logo can be a function, not a constant. Rules for maintaining recognizability across generated variation. The tension between consistency and uniqueness as a design parameter.

---

## 6. DIGITAL DESIGN SYSTEMS

### 6.1 Atomic Design (Brad Frost, 2013)
**Origin:** United States. Brad Frost's *Atomic Design* methodology. **Visual signature:** No single visual signature — Atomic Design is a structural methodology. UI composed of atoms (color swatch, button) → molecules (search form) → organisms (header) → templates → pages. **Contributes:** The hierarchical composition model that all modern component libraries follow. The vocabulary (atoms, molecules, organisms) for discussing component granularity. The principle that design systems are built bottom-up from fundamental elements.

### 6.2 Design Tokens Movement (2014+)
**Origin:** Salesforce Lightning Design System (Jina Anne, Jon Levine, 2014); W3C Design Tokens Community Group (2019+). **Visual signature:** No visual signature — tokens are an abstraction layer. Named key-value pairs (`$color-primary: #0f62fe`) that store design attributes in a platform-agnostic format. **Contributes:** The token abstraction itself — every visual property is a named variable, never a raw value. Multi-platform consistency (one token → CSS custom property, Android resource, iOS asset catalog, Figma style). Semantic naming convention (role-based, not hue-based). The three-tier taxonomy: global → alias → component tokens.

### 6.3 Material Design (Google, 2014–present)
**Origin:** Google. **Practitioners:** Matías Duarte (design lead), Google Design team. **Visual signature:** "Material" metaphor — surfaces as physical sheets of paper with elevation, shadow, and motion. Bold color, 4dp/8dp grid, Roboto typeface, FAB (floating action button), ripple touch feedback, motion as communication. Material 3 (2021): dynamic color from wallpaper, rounded shapes, more expressive. **Contributes:** Elevation/shadow as hierarchy mechanism. Motion as a first-class design language (choreographed transitions, shared-element transforms). The concept of "Material as medium" — design grounded in physical metaphor. Density as an explicit toggle (default, comfortable, compact).

### 6.4 Human Interface Guidelines (Apple, 1987–present)
**Origin:** Apple. First published 1987 for Macintosh; continuously evolved through iOS, macOS, watchOS, visionOS. **Visual signature:** Evolved across eras — skeuomorphic (pre-2013), flat with depth cues (iOS 7+), glassmorphism and spatial (visionOS 2023+). Constants: SF Pro typeface, semantic system colors, vibrancy/blur effects, spring-based physics animation, haptic feedback vocabulary. **Contributes:** Platform-native design thinking — the system adapts to hardware capabilities. Spring physics as the default animation model (tension/damping, not cubic-bezier). Haptic feedback as a design element. Spatial computing design vocabulary (materials, depth, interaction zones). The principle that platform conventions are not optional.

### 6.5 Fluent Design System (Microsoft, 2017–present)
**Origin:** Microsoft. Successor to Metro/Modern design language. **Visual signature:** Acrylic material (frosted glass blur), Reveal highlight (light follows cursor), depth via parallax, connected animations across views, Segoe UI typeface. Fluent 2 (2023): token-based, cross-platform (web, iOS, Android, Windows). **Contributes:** Material transparency as a spatial cue. "Light as an input" — interactive illumination that responds to pointer position. Cross-platform design token architecture that serves both native and web.

### 6.6 Ant Design (2015+) / Chakra UI / Tailwind (2020s ecosystem)
**Origin:** Global open-source. **Practitioners:** Ant Group (Ant Design), Segun Adebayo (Chakra UI), Adam Wathan (Tailwind CSS). **Visual signature:** Ant Design: enterprise-grade Chinese-origin system, comprehensive component library, blue primary, clean layout, internationalization-first. Chakra UI: accessible-by-default, composable primitives, style-props API. Tailwind: utility-first CSS framework, design through constraint (a fixed scale of spacing, colors, type). **Contributes:** Ant Design demonstrates CJK-first internationalization and enterprise density variants. Chakra demonstrates accessibility as architectural foundation. Tailwind demonstrates that a constrained utility vocabulary IS a design system — every class is a token.

---

## 7. ACCESSIBILITY STANDARDS

### 7.1 WCAG 2.x (W3C, 1999–2023)
**Origin:** W3C Web Accessibility Initiative. WCAG 1.0 (1999), 2.0 (2008), 2.1 (2018), 2.2 (2023). **Principles:** Perceivable, Operable, Understandable, Robust (POUR). **Contributes:** The non-negotiable floor: 4.5:1 contrast for normal text, 3:1 for large text (AA level). Focus management requirements (visible focus indicators, logical tab order). Semantic markup as a design requirement, not a development afterthought. The `prefers-reduced-motion` media query as a mandatory consideration for all motion. Touch target minimum (44×44 CSS pixels per 2.2). This is the single standard that trumps all aesthetic preferences.

### 7.2 Section 508 (United States)
**Origin:** Section 508 of the Rehabilitation Act, as amended (1998, refreshed 2017 to align with WCAG 2.0 AA). **Scope:** All U.S. federal government ICT (information and communications technology). **Contributes:** Legal mandate that establishes WCAG AA as a procurement requirement for any system sold to the U.S. government. Forces design systems targeting government/enterprise to treat accessibility as a hard constraint, not a best practice.

### 7.3 ISO 7010 (International Safety Symbols)
**Origin:** International Organization for Standardization. Standardized graphical symbols for safety signs. **Visual signature:** Circle/triangle/square shapes with prescribed colors (red = prohibition, yellow = warning, blue = mandatory, green = safe condition). Simple geometric pictograms. **Contributes:** Proof that pictograms can be universal across cultures and languages. Shape-as-meaning (not just color-as-meaning). A model for designing status/feedback iconography that communicates without text.

### 7.4 EN 301 549 (European Accessibility Standard)
**Origin:** European Telecommunications Standards Institute (ETSI), mandated by EU Directive 2019/882 (European Accessibility Act). **Scope:** ICT products and services sold in the EU. Harmonizes with WCAG 2.1 AA but extends to non-web ICT: mobile apps, kiosks, ATMs, e-readers, telephony. **Contributes:** Expands accessibility thinking beyond web to all digital touchpoints. Requires accessibility in documents (PDF/UA), multimedia, and two-way communication — not just interactive UI. Forces design systems to consider accessible document output, not only accessible web output.

---

## 8. DATA VISUALIZATION

### 8.1 Edward Tufte (1983–present)
**Origin:** United States. *The Visual Display of Quantitative Information* (1983), *Envisioning Information* (1990), *Visual Explanations* (1997), *Beautiful Evidence* (2006). **Principles:** "Above all else show the data." Maximize the data-ink ratio — every mark on a chart should convey information. Eliminate chartjunk (decorative, non-informative elements). Use small multiples for comparison. Sparklines for inline data. The lie factor: visual representation should not distort the data. **Contributes:** The philosophical backbone of all data visualization: clarity, precision, and honesty. The data-ink ratio as a metric for chart quality. The rule against 3D chart effects (they distort perception). The principle that labels and annotations are part of the data display, not decorations.

### 8.2 Jacques Bertin / Semiology of Graphics (1967)
**Origin:** France. *Sémiologie Graphique* (1967). **Principles:** Defined seven visual variables for encoding data: position, size, shape, value (lightness), color (hue), orientation, and texture. Classified data types (nominal, ordinal, quantitative) and mapped appropriate visual variables to each. **Contributes:** The theoretical foundation for choosing visual encoding: use position for quantitative data (most accurate), color hue for categorical data (pre-attentive processing), size for magnitude. The principle that the choice of visual variable should match the data type — not be arbitrary or decorative.

### 8.3 Contemporary Data Visualization (D3, Observable, Vega-Lite, 2010s–2020s)
**Origin:** Global. **Practitioners:** Mike Bostock (D3.js, Observable), Jeffrey Heer (Vega, Vega-Lite, Altair), Nadieh Bremer (data art), Giorgia Lupi (data humanism). **Visual signature:** Grammar-of-graphics approach (data → mark → encoding → scale → guide). Interactive exploration. Responsive charts. Accessible SVG with ARIA. **Contributes:** The component model for charts (axes, legends, marks, scales as composable parts). Accessibility requirements for data visualization (tabular alternatives, pattern fills for color-blind users, ARIA roles for chart elements). Responsive chart behavior (reflow, progressive disclosure of detail at larger sizes).

---

## 9. ART MOVEMENTS

### 9.1 Russian Constructivism (1910s–1930s)
**Origin:** Soviet Russia. **Practitioners:** El Lissitzky, Alexander Rodchenko, Varvara Stepanova, Gustav Klutsis. **Visual signature:** Dynamic diagonal composition, photomontage, bold geometric forms, red-black-white palette, typography as architectural element, propaganda poster aesthetics. **Contributes:** Diagonal as energy — compositional dynamism without curved forms. The integration of photography and geometry. Red as a power color. Typography as structural material, not just information carrier. The poster as a complete design system in miniature.

### 9.2 Minimalism / Hard-Edge Painting (1960s–1970s)
**Origin:** New York. **Practitioners:** Donald Judd, Dan Flavin, Frank Stella, Ellsworth Kelly, Agnes Martin. **Visual signature:** Extreme reduction — single colors, geometric forms, repetition, industrial materials, the rejection of illusionism and narrative. "What you see is what you see" (Stella). **Contributes:** The philosophical justification for reduction in design systems — eliminate everything that does not serve a clear function. The power of a single color field. Repetition as rhythm. The principle that simplicity is not emptiness but concentration.

### 9.3 Concrete Art (1930s–1960s)
**Origin:** Europe. Coined by Theo van Doesburg (1930), developed by Max Bill. **Practitioners:** Max Bill, Richard Paul Lohse, Karl Gerstner, Verena Loewensberg. **Visual signature:** Art constructed entirely from geometric and mathematical elements — no reference to nature or narrative. Systematic color, serial composition, mathematical structure. **Contributes:** The direct bridge between Swiss design and fine art. The proof that mathematical structure is not cold — it can be beautiful, dynamic, and expressive. Gerstner's "programmes" concept: art (and design) as a system of rules that generates variation.

### 9.4 Pop Art (1950s–1970s)
**Origin:** United Kingdom and United States. **Practitioners:** Andy Warhol, Roy Lichtenstein, Richard Hamilton, Jasper Johns, Claes Oldenburg. **Visual signature:** Mass-media imagery, commercial techniques (screenprinting, Ben-Day dots), bold flat color, repetition with variation, irony, high-low culture collision. **Contributes (for expressive systems):** Permission for bold, saturated color palettes. Repetition-with-variation as compositional strategy. The Ben-Day dot / halftone as a texture vocabulary. The idea that "low" sources (commerce, advertising, everyday objects) can be elevated through design treatment.

### 9.5 Psychedelic / Countercultural Graphics (1960s–1970s)
**Origin:** San Francisco, London. **Practitioners:** Wes Wilson, Victor Moscoso, Stanley Mouse, Bonnie MacLean, Martin Sharp. **Visual signature:** Extreme color vibration (high-saturation complementary pairs), distorted organic letterforms, Art Nouveau revival curves, dense visual fields, perceptual ambiguity. **Contributes (for expressive systems):** High-saturation color juxtaposition as a deliberate tool (not an error). Organic, non-geometric typography. The principle that legibility can be intentionally compromised for aesthetic/emotional effect — when the context permits. Decorative density as a legitimate aesthetic.

### 9.6 Punk / Zine Aesthetics (1970s–1980s)
**Origin:** UK, US. **Practitioners:** Jamie Reid (Sex Pistols), Arturo Vega (Ramones), Raymond Pettibon (Black Flag), Riot Grrrl zine makers. **Visual signature:** Cut-and-paste ransom-note typography, xerox grain, hand-drawn elements, deliberate crudeness, collage, photocopied texture, DIY production values elevated to aesthetic choice. **Contributes (for analog-handcraft systems):** Imperfection as authentic voice. Xerox/photocopy texture as a specific material quality. Cut-and-paste as a compositional method. The philosophical position that polish can be dishonest — rawness can communicate more truthfully than refinement.

### 9.7 Vaporwave / Digital Nostalgia (2010s)
**Origin:** Internet culture. **Practitioners:** Macintosh Plus (music), various anonymous graphic designers on Tumblr, Reddit, Twitter. **Visual signature:** Pastel color palettes (pink, cyan, lavender), Roman/Greek bust imagery, retro computing aesthetics (early Mac/Windows UI), Japanese text as decorative element, VHS glitch artifacts, gradient meshes, chrome/metallic text effects. **Contributes (for expressive/generative systems):** Digital artifact as aesthetic material (glitch, compression, scan lines). Nostalgia as a deliberate design register. The recontextualization of obsolete UI patterns as decorative elements. Gradient mesh as a color application method.

### 9.8 De Stijl / Neoplasticism (1917–1931)
**Note:** Primary entry is in section 2.2 (Grid and Layout Traditions) and section 3.3 (Color Theory). Listed here for cross-reference. **Contributes to Art Movements context:** The aspiration to universality — design that transcends individual culture. The reduction of visual language to absolute fundamentals (line, plane, primary color). The proposition that asymmetric balance is more dynamic and modern than symmetry.

---

## 10. MOTION TRADITIONS

### 10.1 Saul Bass Title Sequences (1950s–1990s)
**Origin:** United States. **Practitioners:** Saul Bass, with collaborator Elaine Bass. Key works: *The Man with the Golden Arm* (1955), *Vertigo* (1958), *North by Northwest* (1959), *Psycho* (1960), *Goodfellas* (1990), *Casino* (1995). **Visual signature:** Reduction of a film's essence to a kinetic graphic composition. Geometric animation (spirals, bars, cut-paper forms). Typography in motion — words that enter, exit, transform. Narrative communicated through abstract form and movement alone. **Contributes:** The principle that motion carries meaning — every movement should communicate something about the content it introduces. The concept of a "title sequence" as a design system in time (consistent palette, consistent geometric vocabulary, consistent rhythm). The proof that abstract motion can be as emotionally powerful as figurative imagery.

### 10.2 Motion Graphics / MoGraph Tradition (1990s–present)
**Origin:** Global, accelerated by After Effects (1993) and Cinema 4D. **Practitioners:** Kyle Cooper (Se7en titles), MK12, Buck, Imaginary Forces, Gmunk. **Visual signature:** Sophisticated kinetic typography, 3D camera moves through typographic space, particle systems, procedural animation, data-driven motion. **Contributes:** Complex choreography models — the coordination of multiple elements across time. The concept of "easing" as emotional character (sharp ease-out = decisive; slow ease-in = contemplative). The stagger pattern (sequential element animation with consistent delay). Camera as a navigational metaphor.

### 10.3 Physics-Based UI Motion (iOS 7+, 2013–present)
**Origin:** Apple (iOS 7), later adopted by Material Design and others. **Practitioners:** Apple Human Interface team, Google Material Motion team. **Visual signature:** Spring dynamics replace cubic-bezier curves. Elements have mass, velocity, and momentum. Gestures have inertia — a flung list decelerates naturally. Rubber-banding at scroll boundaries. Animations are interruptible and redirectable mid-flight. **Contributes:** Spring physics as the primary motion model: tension, friction, mass instead of duration and curve. The requirement that animations be interruptible (the user can redirect a transition before it completes). Gesture-driven animation where the animation's progress tracks the user's finger, not a timeline. Reduced-motion as a first-class consideration.

### 10.4 Choreographic Design (2010s–present)
**Origin:** The application of choreographic thinking (from dance) to interaction design. **Practitioners:** Rachel Nabors (*Animation at Work*, A Book Apart), Sarah Drasner (*SVG Animations*, O'Reilly), Val Head (*Designing Interface Animation*). **Visual signature:** No single signature — choreographic design is a methodology. It treats UI animation as a performance: elements have entrances, exits, and relationships. Timing is relational (this element waits for that one). Spatial continuity (where an element came from and where it goes matters). **Contributes:** The stagger-delay formula (per-element delay in a group animation, capped to prevent sluggishness). The concept of "animation budget" — total animation time per interaction should not exceed a threshold. Entrance/exit choreography patterns. The principle that motion should maintain spatial continuity — if a detail view opens from a card, the card should visually transform into the view, not disappear and be replaced.

### 10.5 Game UI Motion Traditions
**Origin:** Video game heads-up display (HUD) design, spanning arcade (1970s) through modern AAA titles. **Practitioners:** Bungie (Destiny UI), Naughty Dog (The Last of Us), CD Projekt Red (Cyberpunk 2077), various. **Visual signature:** Real-time feedback loops — every player action produces immediate visual response. Health bars, damage indicators, ammo counters that animate fluidly. Contextual UI that appears/disappears based on game state. High information density with zero latency. **Contributes (for data-dense and motion systems):** Real-time data animation (values that tick up/down smoothly rather than snapping). Contextual show/hide patterns driven by state, not user action. The "juice" principle — small animations that make interactions feel satisfying (a counter that overshoots then settles). Performance as a hard constraint (animation must never block the frame budget).

---

## 11. CRAFT & MATERIAL TRADITIONS

### 11.1 Letterpress / Typographic Printing (1440s–present)
**Origin:** Germany (Gutenberg, c. 1440), evolved through industrial and revival eras. **Practitioners:** Historically: Aldus Manutius, John Baskerville, Giambattista Bodoni. Revival: Hamilton Wood Type Museum, Hatch Show Print (Nashville), contemporary letterpress studios. **Visual signature:** Impression (debossed text from physical pressure), ink density variation (heavier at edges), registration imperfection in multi-color work, the tactile quality of type pressed into soft paper. **Contributes (for analog-handcraft systems):** Impression texture — simulated deboss effects. Ink pooling at letterform edges as a rendering detail. The warm, physical quality of printed matter. The constraint that shapes what's possible (limited typefaces, limited colors per pass) as a generative force.

### 11.2 Risograph / Zine Culture (1980s–present)
**Origin:** Japan (Riso Kagaku Corporation, 1980), adopted globally by artists and independent publishers. **Visual signature:** Misregistration between color layers (deliberate or embraced), grain/noise from the stencil process, limited spot-color palette (fluorescent pink, blue, green, orange, yellow), halftone patterns, paper show-through, the aesthetic of imperfect reproduction. **Contributes (for analog-handcraft systems):** Misregistration as a deliberate visual effect — color layers that intentionally do not align perfectly. Fluorescent/spot-color palettes that differ from standard CMYK or RGB. Halftone as a texture vocabulary. The grain quality specific to stencil duplication. The ethos that process constraints produce distinctive beauty.

### 11.3 Japanese Woodblock Printing (Ukiyo-e, 1600s–1900s)
**Origin:** Japan. **Practitioners:** Katsushika Hokusai, Utagawa Hiroshige, Kitagawa Utamaro. Revival/influence: Shin-hanga movement (early 20th century). **Visual signature:** Flat color planes without gradation, strong outlines, limited palette per print (one block per color), subtle paper texture, registration marks, the bokashi technique (gradient achieved by wiping ink). **Contributes (for analog-handcraft and cultural systems):** Flat color as a positive aesthetic choice (not a limitation). Strong outline as a unifying visual element. The tension between precise registration and organic variation. Color-as-layer thinking (each color is a discrete pass, not a continuous blend).

### 11.4 Textile Patterns / Woven Design
**Origin:** Global — every culture has textile traditions. **Practitioners:** William Morris (Arts & Crafts), Anni Albers (Bauhaus weaving), Kente cloth weavers (Ghana/Ashanti), Navajo weavers, Scandinavian textile designers. **Visual signature:** Repeating geometric or organic motifs, grid-based construction (warp/weft), limited color per technique, bilateral or rotational symmetry, pattern as identity. **Contributes (for analog-handcraft and cultural systems):** Pattern libraries — systematic repeating motifs derived from mathematical symmetry groups. Grid-based construction that maps directly to pixel grids. Color limitation as a constraint-driven palette. The concept of pattern as cultural identity — specific motifs carrying specific meanings.

### 11.5 Architectural Drafting / Blueprint Aesthetics
**Origin:** Engineering and architectural drawing traditions, formalized in the 18th–19th centuries. **Visual signature:** White-on-blue (cyanotype) or black-on-white technical drawings, precise line weights (thick for cut, thin for projection, dashed for hidden), standardized dimension notation, orthographic projection, section hatching. **Contributes (for data-dense and analog systems):** Systematic line-weight hierarchy as a communication tool. Dimension annotation patterns. The blueprint aesthetic as a visual vocabulary (white-on-blue, technical precision, the romance of engineering drawing). Section/hatching patterns for distinguishing materials or zones in diagrams.

---

## 12. CULTURAL DESIGN TRADITIONS

### 12.1 Chinese Painting Composition
**Origin:** China, spanning thousands of years. **Practitioners:** Historically: Gu Kaizhi, Ma Yuan (the "One-Corner Ma"), Ni Zan. Contemporary graphic design: Kan Tai-Keung, Wang Xu, Stanley Wong (anothermountainman). **Visual signature:** Asymmetric balance with deliberate emptiness, the "one-corner" composition (subject placed off-center with vast negative space), vertical scroll format, calligraphic integration of text and image, ink wash gradation, the "three distances" (high, deep, level) for spatial depth without Western perspective. **Contributes (for cultural extension):** Radical asymmetry with large empty space as a deliberate composition strategy. Vertical format as a primary (not secondary) layout direction. The integration of calligraphy and image as a unified composition. The principle that emptiness carries equal weight to presence.

### 12.2 Islamic Geometric Pattern
**Origin:** The Islamic world, from the 8th century onward, spanning North Africa, the Middle East, Central Asia, and Iberia. **Practitioners:** Historically: anonymous master geometers of the Alhambra, Topkapi Palace, Isfahan mosques. Contemporary: Eric Broug (researcher/educator), Zarah Hussain (digital Islamic pattern artist). **Visual signature:** Complex interlocking geometric patterns derived from circles and polygons, infinite repeat (patterns that tile infinitely, suggesting the infinite nature of creation), no figurative imagery, mathematical precision, symmetry groups (p6m, p4m, p3m1). **Contributes (for cultural and generative extensions):** Algorithmically generatable patterns — Islamic geometric patterns are inherently parametric (defined by construction rules, not fixed drawings). Tiling as a design principle. The concept of pattern as spiritual expression — geometry as a reflection of cosmic order. Pattern complexity as a hierarchy signal (more complex = more important surface).

### 12.3 African Textile and Visual Design
**Origin:** Sub-Saharan Africa, diverse traditions. **Practitioners:** Kente weavers of Ghana (Ashanti and Ewe), Adire cloth makers of Nigeria (Yoruba indigo resist-dye), Shoowa/Kuba cloth designers of Democratic Republic of Congo, Ndebele mural painters of South Africa. **Visual signature:** Bold geometric abstraction, high-contrast color combinations, patterns encoding social status and identity, asymmetric rhythm within symmetric structure, handcraft variation as a feature not a flaw. Kente: narrow-strip weaving with symbolic color and pattern combinations. Kuba cloth: complex interlocking geometric motifs cut from raffia. Ndebele murals: bright flat color in geometric compositions. **Contributes (for cultural and analog-handcraft extensions):** Pattern as encoded meaning (specific patterns carry specific social/cultural messages). Bold color as cultural norm (not "excess"). Geometric abstraction as a sophisticated visual language. Handcraft variation as authenticity signal.

### 12.4 Indigenous Australian Visual Traditions
**Origin:** Australia. The oldest continuous art traditions on Earth (40,000+ years). **Practitioners:** Emily Kame Kngwarreye, Clifford Possum Tjapaltjarri, Rover Thomas. Contemporary design: Balarinji (airline livery design for Qantas), Clothing the Gaps. **Visual signature:** Dot painting (Western Desert tradition), cross-hatching/rarrk (Arnhem Land tradition), x-ray style (depicting internal structures), earth-tone palettes (ochre, sienna, white, black), aerial/map-view perspective, symbolic representation of landscape and Dreaming tracks. **Contributes (for cultural extension):** Dot-field as a texture and spatial-encoding technique. Earth-tone palette derived from natural pigments. Aerial perspective (map-view) as a primary compositional viewpoint. The principle that art and information are inseparable — paintings are simultaneously aesthetic objects and navigational/informational maps. **Critical note:** Indigenous Australian visual traditions carry deep cultural and intellectual property significance. Their use in design systems requires genuine engagement with custodians and communities, not surface appropriation of visual elements.

### 12.5 Mexican Muralism and Popular Graphics
**Origin:** Mexico, 1920s–1960s (muralism), ongoing (popular graphics). **Practitioners:** Diego Rivera, David Alfaro Siqueiros, José Clemente Orozco (muralism). Eduardo Muñoz Bachs (Cuban poster art, adjacent tradition). Contemporary: Alejandro Magallanes, el Fantasma de Heredia. **Visual signature:** Large-scale narrative composition, bold flat color, social/political content as primary purpose, integration of indigenous and European visual traditions, papel picado (perforated paper) as decorative pattern, Día de Muertos skeleton imagery (José Guadalupe Posada's calaveras). **Contributes (for cultural and expressive extensions):** Mural-scale composition thinking — design that works at wall-size. Narrative illustration as a structural design element. The synthesis of indigenous and colonial visual traditions into a distinctive hybrid. Bold, saturated color palettes rooted in cultural context. The principle that design serves a social purpose beyond commerce.

### 12.6 Japanese Spatial and Material Design
**Origin:** Japan. Distinct from (but related to) the wabi-sabi entry in section 4.4. **Practitioners:** Shiro Kuramata, Tokujin Yoshioka, Nendo (Oki Sato), Issey Miyake (fashion/material), Kenya Hara, Hara Design Institute. **Visual signature:** Material transparency and translucency (acrylic, glass, fabric), extreme attention to tactile quality, packaging as an art form (wrapping, unfolding, reveal), miniaturization without loss of completeness, the concept of "suki" (refined taste through restraint), paper and folding as structural elements. **Contributes (for spatial-3d and analog-handcraft extensions):** Material as meaning — the choice of material IS the design decision. Translucency and layering as spatial depth cues (applicable to glassmorphism, visionOS materials). Packaging/unboxing as an interaction design model (progressive reveal, ceremony of access). The principle that reduction should not mean deprivation — a minimal object should feel more complete, not less.

---

## Usage

When performing Phase 2 of the analysis prompt, use this catalog as a lookup table. For each Phase 1 observation, scan the catalog for matching visual signatures. When a match is found, read the full entry and its "Contributes" field to determine what to include in the influence dossier.

The catalog is intentionally broader than any single design sample will need. Most analyses will reference 8-16 entries. The rest serve as negative evidence — confirming that certain traditions are NOT present helps define the system's aesthetic identity by exclusion.
