# Extension: Expressive Brand

**Activated when:** Illustrations are present, photography has distinctive art direction, the design has perceptible personality, color usage is emotionally expressive.

## What This Extension Adds

This extension augments the core system with four capabilities the rationalist template lacks: illustration direction, photographic art direction, brand voice specification, and personality tokens. Without these, any brand-forward system loses its soul in translation.

## Template Section 13: expressive_brand

### Illustration

Define the complete illustration style guide as structured data:

**Style classification:** flat vector, isometric, hand-drawn, 3D rendered, collage, geometric abstract, character-based, pattern-based, photographic composite.

**Color treatment:** full palette (uses all system colors), monochromatic (one family + neutrals), duotone (two families), limited (3-4 specific swatches from the palette).

**Structural properties:** line weight (hairline/thin/medium/thick), corner treatment (sharp/rounded/organic), fill style (solid/gradient/textured/outlined), perspective (flat/isometric/perspective).

**Character style (if applicable):** geometric figures, realistic proportions, caricature, abstract silhouettes, none (no characters).

**Do/Don't rules:** Explicit lists. Examples: "DO use consistent stroke weight across all illustrations. DON'T mix illustration styles within a single page. DO use brand accent colors for illustration highlights. DON'T use photorealistic shadows on flat illustrations."

### Photography

**Art direction:** documentary (candid, real situations), studio-lit (controlled, product-focused), editorial (styled, narrative-driven), lifestyle (aspirational, environmental), abstract (close-up textures, patterns, macro).

**Color grading tokens:** Specify as color adjustment parameters: `{temperature: warm/neutral/cool, saturation: 0-100, contrast: low/medium/high, highlights: warm/neutral/cool, shadows: warm/neutral/cool}`. These enable consistent grading across different source images.

**Composition rules:** Rule of thirds, centered subject, full-bleed, contained within shape mask, overlaid with text (and if so, which text token is safe on which photo types).

**Subject guidelines:** What to photograph, how to frame people (eye contact/candid, diversity requirements, cropping rules — never crop at joints), acceptable backgrounds.

### Brand Voice

**Personality adjectives:** 3-5 adjectives that describe the brand's character (e.g., "confident, warm, precise, curious, grounded"). These inform not just writing but visual decisions — a "warm" brand uses warmer color grades, more rounded corners, and more organic spacing.

**Tone spectrum:** Position on two axes: formal (1) ←→ casual (10), and reserved (1) ←→ enthusiastic (10). This gives agents a numeric target rather than a subjective impression.

**Writing rules:** Sentence length targets, active/passive voice preference, jargon policy, humor policy, contraction usage.

**Vocabulary:** Preferred terms (use "start" not "commence"; use "people" not "users") and explicitly avoided terms.

### Personality Tokens

Numeric scores (0-10) that parameterize the system's character across all categories:

**warmth** (0 = clinical, 10 = warm): Affects color temperature, corner radii, illustration style, photography grading, voice formality.

**playfulness** (0 = serious, 10 = playful): Affects motion bounciness, illustration complexity, color saturation, vocabulary informality.

**energy** (0 = calm, 10 = energetic): Affects motion speed, color vibrancy, spacing density, type weight.

**formality** (0 = casual, 10 = formal): Affects typeface selection, spacing generosity, color restraint, writing style.

**density** (0 = spacious, 10 = dense): Affects spacing scale selection, component sizes, line-height, paragraph spacing.

These tokens function as meta-parameters — they influence how the core tokens are selected and applied. An agent can use them to calibrate decisions: "The personality warmth is 7/10, so I should use rounded corners (4px radius), warm gray tones, and the warmer end of the accent palette."

## Derivation Procedure

1. From Phase 1 observations, classify the illustration style, photography direction, and overall personality.
2. From the influence dossier, identify which influences contribute to the expressive layer (Pop Art, Memphis, Arts & Crafts, Scandinavian warmth, etc.).
3. Assign personality token values based on the Phase 1 aesthetic character assessment.
4. Derive specific rules from the combination of personality values and identified influences.
5. Cross-validate: ensure personality tokens are reflected consistently across ALL categories (a system scored warmth=8 should not have ice-cold blue as its primary color).

## Integration with Core System

Personality tokens do not replace core tokens — they modulate them. The core color palette still exists; personality warmth determines which grades are favored. The core spacing scale still exists; personality density determines which steps are preferred. The core type tokens still exist; personality formality determines whether the system favors the heavier or lighter end of the weight range.
