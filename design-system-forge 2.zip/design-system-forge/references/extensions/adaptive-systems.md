# Extension: Adaptive Systems

**Activated when:** The system has contextual rules that change based on content type, user role, or viewport; some design decisions are intentionally underdetermined; the specification includes decision trees rather than fixed values.

## What This Extension Adds

The core template treats every specification as a fixed constant — one value per token, one rule per situation. Sophisticated design systems, however, are living organisms with contextual intelligence: the heading style changes for legal content, the density increases for expert users, the color scheme shifts for different product areas, the layout adapts based on content volume rather than just viewport width. This extension provides the structures for specifying these adaptive behaviors as formal rules rather than vague guidelines.

## Specification Structures

### Contextual Overrides

A contextual override is a conditional modification to the base specification. Each override specifies: a trigger condition, the tokens or rules it modifies, the replacement values, and the scope of the override.

Structure: `{id, trigger_condition, scope, overrides: [{token_or_rule, base_value, override_value}], priority, rationale}`.

**Trigger condition types:** content-type (e.g., "when displaying legal text"), user-role (e.g., "when user is admin"), viewport-context (e.g., "when embedded in iframe < 400px"), data-volume (e.g., "when table has > 50 rows"), locale (e.g., "when locale is ar-SA"), time-of-day (e.g., "after 20:00 local time, switch to dark theme"), and feature-flag (e.g., "when beta-features enabled").

**Scope:** What the override affects — a single component, a page section, an entire page, or the whole application.

**Priority:** When multiple overrides apply simultaneously, priority determines which wins. Higher number = higher priority. Same priority = later-defined wins.

Example: `{id: "legal-content-override", trigger: "content-type = legal", scope: "content-area", overrides: [{token: "$body-01", base: {font_family: "IBM Plex Sans"}, override: {font_family: "IBM Plex Serif", line_height_px: 24}}, {token: "$spacing-paragraph", base: {value_px: 16}, override: {value_px: 20}}], priority: 10, rationale: "Legal text requires serif typeface for convention and increased line-height for dense reading"}`.

### Decision Trees

For complex adaptive behaviors that cannot be expressed as simple token overrides, define decision trees. Each tree specifies: the decision point, the inputs the agent evaluates, the branches, and the outcome for each branch.

Structure: `{id, decision_point, inputs: [variable_names], branches: [{condition, outcome, rationale}], default_outcome}`.

Example: `{id: "table-density-decision", decision_point: "What density should this data table use?", inputs: ["row_count", "column_count", "user_expertise"], branches: [{condition: "row_count < 10 AND column_count < 5", outcome: "Use lg (48px) rows with standard spacing", rationale: "Low data volume benefits from spacious layout"}, {condition: "row_count >= 10 AND user_expertise = expert", outcome: "Use xs (24px) rows with micro spacing", rationale: "Expert users with lots of data need density"}, {condition: "row_count >= 10 AND user_expertise != expert", outcome: "Use sm (32px) rows with standard spacing + pagination at 20 rows", rationale: "Non-expert users need readable density with pagination"}], default: "Use md (40px) rows"}`.

### Intentionally Underdetermined Rules

Some design decisions SHOULD be left to the implementing agent's judgment — over-specifying them would produce rigid, context-insensitive output. These are documented as "judgment zones" with guidance rather than fixed rules.

Structure: `{id, domain, guidance, constraints, examples_of_good_judgment, examples_of_bad_judgment}`.

Example: `{id: "hero-image-selection", domain: "editorial pages", guidance: "Select a hero image that establishes the emotional tone of the article content. The image should fill the hero area and work with the overlay heading text.", constraints: ["Image must provide sufficient contrast for overlay text — test with $text-on-color at 4.5:1", "Image aspect ratio must be 16:9 or 21:9", "Image must not contain faces cropped at the jaw or forehead"], examples_good: ["A wide landscape establishing location for a travel article", "An abstract texture establishing mood for an opinion piece"], examples_bad: ["A stock photo of people shaking hands for every business article", "A literal illustration of the article's subject — the image should evoke, not illustrate"]}`.

### Content-Aware Layout

Define layout rules that adapt based on content characteristics rather than just viewport width. These go beyond responsive breakpoints to consider content volume, content type, and content relationships.

Examples: "If a card has no image, expand the text area to fill the card. If a card has both an image and a long description (>140 characters), switch from side-by-side to stacked layout regardless of viewport width. If a navigation menu has >7 items, switch from horizontal to dropdown. If a form has >6 fields, add a progress indicator and split across steps."

## Conflict Resolution

When multiple overrides, decision trees, or adaptive rules produce conflicting outputs, resolve using these precedence rules (highest to lowest): explicit user preference > locale/accessibility override > content-type override > user-role override > viewport override > data-volume override > time-based override > default specification.

Document every potential conflict and its resolution. An agent should never encounter an ambiguous state where two valid rules produce different outputs without a documented resolution path.

## Derivation Procedure

1. From Phase 1 analysis, identify content types, user roles, and contexts visible in the sample. Note where the design appears to adapt (different page types with different layouts, density changes, typeface changes for specific content).
2. For each observed adaptation, determine if it can be expressed as a simple token override or requires a decision tree.
3. Identify areas where the sample appears to leave room for editorial judgment — these become judgment zones.
4. Define conflict resolution rules for any overlapping overrides.
5. Validate: for every possible combination of active overrides, verify that the system produces a coherent, non-contradictory output. If two overrides can both be active and produce conflicting values for the same token, add an explicit priority or merge rule.

## Integration with Core System

Adaptive rules sit above the core specification as a modulation layer. The core spec defines the default state — the system's behavior when no overrides are active. Every override is an explicit, documented departure from the default. The default state must be a complete, coherent system on its own (validated by ADP-03). Overrides modify it; they do not complete it.
