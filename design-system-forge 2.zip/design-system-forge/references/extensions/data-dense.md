# Extension: Data-Dense

**Activated when:** Information density is very high, components are smaller than 32px, the UI is optimized for expert users needing simultaneous visibility of many data points.

## What This Extension Adds

The core system assumes standard-density interfaces where generous spacing and 32-48px component heights support comfortable interaction. Professional tools — financial terminals, medical imaging dashboards, air traffic control displays, code editors, scientific analysis software — require the opposite: maximum information per pixel, with minimal chrome consuming the expert user's screen real estate. This extension provides the micro-scale tokens, ultra-compact component specifications, and density-appropriate rules that make this possible without abandoning the design system's structural integrity.

## Augmented Template Fields

### Micro-Spacing Scale (augments spacing.density_scale)

Add spacing tokens below the standard minimum: `$spacing-micro-01: 1px`, `$spacing-micro-02: 2px`, `$spacing-micro-03: 3px`, `$spacing-micro-04: 4px`, `$spacing-micro-05: 6px`. These are used exclusively within data-dense contexts — never in standard-density UI.

### Micro-Typography Tokens (augments typography.tokens)

Add type tokens for ultra-compact contexts: `$micro-01: {font_size_px: 10, line_height_px: 12, font_weight: 400, letter_spacing: "0.4px"}` and `$micro-02: {font_size_px: 11, line_height_px: 14, font_weight: 400, letter_spacing: "0.32px"}`. These require the primary typeface to be legible at these sizes — humanist sans-serifs with open apertures and clear letterform distinction (I/l/1, 0/O) are critical.

### Ultra-Compact Component Sizes (augments component sizes)

Add two size tiers below sm: `2xs (20px height)` and `xs (24px height)`. At these sizes, internal padding reduces to $spacing-micro-02 (2px) vertical and $spacing-micro-04 (4px) horizontal. Icon size reduces to 12px. Label text uses $micro-01 or $micro-02 tokens.

### Ultra-Condensed Grid Mode (augments grid.grid_modes)

Add a grid mode with 1px or 0px gutters, where content blocks are separated only by 1px borders or subtle background color differences. This mode is used for data tables, spreadsheet-like interfaces, and multi-panel dashboards.

### Density Toggle Pattern

Define a UI pattern that lets users switch between standard density and compact density. This toggle should change: component size tier (lg→sm or sm→2xs), spacing scale (standard→micro), type tokens (body-01→body-compact-01 or body-compact-01→micro-02), and grid mode (wide→condensed). The toggle affects the entire viewport or a defined panel, not individual components.

## Design Rules for Data-Dense Contexts

**Contrast is more important, not less.** At small sizes and tight spacing, contrast failures are amplified. Maintain WCAG AA minimums; consider exceeding them (5:1 for body text). Use strong borders ($border-strong) rather than subtle borders to separate adjacent data cells.

**Monospace for numeric data.** Columns of numbers must use the monospace typeface with tabular (fixed-width) numerals to ensure digit alignment. This is a functional requirement, not a stylistic choice.

**Color coding for rapid scanning.** In expert-user contexts, color IS a primary information channel (traders reading market data, doctors reading vitals). WCAG's "never color alone" rule still applies — pair with position, shape, or text — but the system should define an extended set of status colors with more granularity than the standard 4 (error/success/warning/info). Consider: critical (red), warning (orange), caution (yellow), normal (green), inactive (gray), highlighted (blue), anomaly (purple).

**Keyboard-everything.** Expert users operate primarily via keyboard. Every action must have a keyboard shortcut. The system should define a shortcut namespace to avoid conflicts. Common pattern: single-letter shortcuts in context (e.g., "d" for delete when a row is selected) with modifier keys for global actions (Cmd/Ctrl+S for save).

**Truncation with access.** In tight spaces, text truncation is expected but the full value must be accessible — via tooltip on hover, expansion on click, or a detail panel. Define truncation rules: where to truncate (end for labels, middle for file paths, start for timestamps), and how to indicate truncation (ellipsis character, not CSS overflow:hidden which may not render consistently).

## Derivation Procedure

1. Identify the domain (financial, medical, scientific, development tools) from the sample.
2. Determine the minimum viable text size for the domain's expert users (typically 10-12px).
3. Define the micro-spacing scale as submultiples of the base unit.
4. Add ultra-compact component sizes and verify that all interactive elements maintain a minimum touch/click target (24×24px on desktop, even if the visual element is smaller — use transparent padding to expand the hit area).
5. Define the extended status color set appropriate for the domain.
6. Specify keyboard shortcut conventions.
7. Define truncation rules for the most common data types in the domain.

## Integration with Core System

Data-dense tokens EXTEND the core scales — they do not replace them. The system still has standard-density tokens for onboarding flows, settings pages, and help documentation within the same application. The density toggle pattern allows contexts to switch between scales. Components render differently at different densities but maintain the same token-based architecture.
