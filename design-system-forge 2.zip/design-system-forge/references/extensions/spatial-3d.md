# Extension: Spatial & 3D

**Activated when:** The interface operates in three dimensions, depth cues go beyond flat layering, the target includes AR/VR/XR contexts, or materials/lighting/perspective are design elements.

## What This Extension Adds

The core template's depth model is a stack of flat layers with box-shadows. This extension adds the full spatial vocabulary: coordinate systems, material definitions, lighting rigs, depth-based interaction zones, and spatial audio cues. It enables specification of design systems for visionOS, Quest, WebXR, and any interface where the user exists inside the design rather than looking at it.

## Template Section 15: spatial_3d

### Coordinate System
Define the 3D coordinate system: right-handed Y-up (standard for most platforms), units (meters for XR, pixels for pseudo-3D web), and origin point (user's head position for XR, screen center for web).

### Depth Model
Extend the flat layer model into true z-space. Each layer now has: name, z_position (distance from user in meters or px), blur amount (depth-of-field simulation), opacity, and scale factor (for size-as-depth cues). Define parallax ranges for scroll-linked depth effects.

### Materials Library
Define materials as structured objects with physically-based rendering (PBR) properties: roughness (0=mirror, 1=matte), metalness (0=dielectric, 1=metal), opacity (0-1), base color (references a color token), and optional properties (emissive color, normal map, refraction index for glass). Map to platform conventions: visionOS "glass" material, Quest "passthrough" material.

Standard materials to define: opaque-surface (for solid panels), translucent-glass (for floating panels in XR), frosted-glass (for overlays), matte-surface (for grounded elements), emissive (for status indicators and highlights).

### Lighting
Define a lighting rig: key light (primary directional light: direction vector, intensity, color token, shadow softness), ambient light (intensity, color), and optional accent lights for emphasis. In XR contexts, lighting should adapt to the physical environment (passthrough lighting estimation).

### Spatial Audio
For XR systems, define audio spatialization: distance model (linear/inverse/exponential), rolloff factor, maximum audible distance, and association between UI events and spatial audio cues (e.g., notification sounds originate from the notification panel's 3D position).

### Interaction Zones
Define distance-based behavior tiers: far zone (>2m — element is visible but not interactive), mid zone (1-2m — element is interactive, shows hover states), near zone (<1m — element is manipulable, supports direct touch/grab). Minimum interaction target sizes increase with distance from the user.

## Derivation Procedure

1. Identify the target spatial platform(s) from the sample or user requirements.
2. Map the core layer model to z-space positions appropriate for the platform.
3. Define materials that visually correspond to the core theme (light theme → translucent glass with light tint; dark theme → frosted dark glass).
4. Set up lighting that preserves the color token relationships (avoid lighting that shifts hue perception).
5. Define interaction zones based on platform ergonomics and input modality (hand tracking, controllers, gaze).

## Integration with Core System

Spatial properties augment, not replace, the 2D system. Every spatial element still has a 2D fallback (how it renders on a flat screen). Color tokens are the same; materials reference them. Components are the same; interaction zones modify their touch target sizes. The system is one system expressed in two or three dimensions as the medium demands.
