# Extension: Generative & Parametric

**Activated when:** Visual elements show algorithmic variation, identity marks are generated rather than fixed, rules produce a family of outputs rather than one canonical form.

## What This Extension Adds

The core template assumes every value is a fixed constant. This extension adds the specification structures for design systems where certain values are functions — producing variation within constraints. The result is a system where every instance is unique but every instance is recognizably part of the same family. Think of it as the difference between a typeface (fixed forms) and handwriting (consistent character with natural variation).

## Template Section 16: generative_parametric

### Parameters

Each parameter defines a variable axis of the system. Structure: `{name, type (continuous/discrete/categorical), min, max, default, step (for discrete), options (for categorical), description}`.

Examples: `{name: "accent-hue-rotation", type: continuous, min: 0, max: 360, default: 220, description: "Rotates the primary accent color around the hue wheel — each instance gets a unique accent while maintaining saturation and lightness"}`. Or: `{name: "grid-density", type: discrete, min: 12, max: 20, step: 4, default: 16, description: "Column count varies per instance based on content type"}`.

### Rules

Generative rules define the relationship between parameters and visual output. Structure: `{condition, output, variation_range}`.

Example: `{condition: "parameter accent-hue-rotation is set", output: "primary palette grades 10-100 are computed by rotating the base blue family by the rotation amount while preserving chroma and lightness", variation_range: "output hue varies but saturation stays within 5% of base"}`.

### Invariant Constraints

The non-negotiable rules that ALL generated instances must satisfy, regardless of parameter values. These are the "this never changes" half of the system.

Examples: contrast ratios always meet WCAG AA; the grid base unit is always 8px; the typeface family never changes; the logo lockup proportions never change; the spacing scale never changes. The invariants define the "family resemblance" that makes all generated instances recognizably related.

### Variation Axes

The "this CAN change" complement to invariants. Each axis specifies what varies, the range of variation, and the visual effect.

Examples: color hue (within the primary family, ±30°); corner radius (2-8px); illustration character pose (from a defined set); background pattern (generated from a seed); card aspect ratio (from approved list: 16:9, 4:3, 1:1).

### Seed Strategy

How randomness is controlled. Options: **deterministic from input hash** (same input → same output, reproducible), **random per instance** (each generation is unique, non-reproducible), **user-controlled** (seed is a visible parameter), **time-based** (output changes over time, e.g., seasonal themes).

For most identity systems, deterministic hashing is preferred — it ensures the same business card for the same person every time, while different people get different cards.

### Identity Mark Generation

If the system generates logos or identity marks (like MIT Media Lab's generative identity), define: the generation algorithm (as a description an agent can implement), the invariant geometric constraints (what stays the same), the variation axes (what changes), and quality criteria (how to evaluate whether a generated mark is "good").

## Derivation Procedure

1. From Phase 1 observations, identify which elements vary and which are constant.
2. Define the invariant constraints (the "family DNA" that never changes).
3. Define the parameters that control the variation.
4. For each parameter, determine its type (continuous, discrete, categorical) and its range from the observed sample.
5. Write the rules that transform parameter values into visual output.
6. Choose a seed strategy based on the use case.
7. Validate: generate 5 test instances at different parameter values. Verify all invariants hold. Verify the instances look related but distinct.

## Integration with Core System

Parameters modulate core tokens — they do not replace the token system. A generated instance still resolves every visual property to a token; the generative layer determines WHICH token value applies for that instance. The QA framework validates each generated instance independently against the core checklist; it also validates that the generative rules satisfy GEN-01 through GEN-04.
