# Extension: Cultural Traditions

**Activated when:** Primary language uses non-Latin script, color choices reflect cultural symbolism beyond Western conventions, layout direction is RTL-primary, or typographic traditions differ from Western norms.

## What This Extension Adds

The core template's typography, color, and layout systems assume a Western Latin-script context. This extension provides the specification structures needed for CJK, Arabic, Devanagari, and other script-based design traditions, along with culturally-specific color semantics and layout conventions that go far beyond a simple RTL boolean flag.

## Augmented Template Fields

### Typography Augmentation

**Script-specific typefaces:** Add entries to `typography.typefaces` for each target script. Each entry needs: family name, fallback stack, available weights, and the script-specific metrics that differ from Latin (e.g., CJK characters sit in a square em-box, Arabic requires contextual shaping, Devanagari has a headline bar that affects line-height calculation).

**Vertical text tokens:** For CJK contexts where vertical text is used (book spines, traditional layouts, certain UI elements), define tokens with rotated metrics — the "line-height" becomes inter-column spacing and "letter-spacing" becomes inter-character vertical spacing.

**Minimum size adjustments:** CJK characters have more strokes and require larger minimum sizes for legibility. Standard recommendation: CJK body text minimum 14px (vs. 12px for Latin). Arabic with diacritics: minimum 16px. Devanagari: minimum 14px.

**Mixed-script spacing:** When Latin and CJK text appear in the same line, define inter-script spacing rules — typically a thin space (U+2009) or quarter-em space between script boundaries.

### Color Augmentation

**Cultural semantics mapping:** Define a `color.cultural_semantics` object that maps colors to their cultural meaning in the target locale. This is NOT a simple lookup table — it acknowledges that the same color carries different weight in different contexts.

Examples: In Chinese culture, red signifies luck, prosperity, and celebration — it is the appropriate color for positive actions, not warnings. White signifies mourning in many East Asian cultures — using it for "clean" or "pure" states may carry unintended connotations. Green carries strong Islamic religious significance. Purple has royal associations in European traditions but different meanings elsewhere.

**Locale-aware token overrides:** Define token overrides keyed by locale. Example: `$support-success` might remain green globally, but `$celebration` and `$positive-action` might map to red-60 in zh-CN locale and green-60 in en-US locale.

### Layout Augmentation

**RTL as first-class architecture:** Beyond mirroring left→right, specify: reading order for mixed-direction content (BiDi algorithm conformance level), numeral rendering (Western Arabic vs. Eastern Arabic vs. Devanagari numerals), punctuation behavior, and content alignment in mixed-script contexts.

**Layout patterns specific to scripts:** Arabic layouts often use more generous line-spacing due to diacritics. CJK layouts may use grid-based character placement (each character occupying one grid cell) for formal/traditional contexts. Indic scripts may require extra vertical space for stacked conjuncts.

**Calendar and date formatting:** Different cultural contexts use different calendars (Gregorian, Hijri, Buddhist, Japanese Imperial Era). Date picker components must accommodate these, not just format dates differently but support entirely different calendar systems.

## Derivation Procedure

1. Identify the target scripts and locales from the sample's content or user requirements.
2. Research the typographic traditions for each script (use the influence catalog, section 1.6-1.8).
3. Select script-specific typefaces that harmonize with the primary Latin-script face (similar x-height proportions, compatible weight range, shared design philosophy).
4. Research cultural color meanings for the target locale(s). Source this from academic/design references, not stereotypes.
5. Define locale-aware token overrides where cultural meanings diverge from Western defaults.
6. Specify RTL layout rules if applicable, including component-level mirroring details.
7. Adjust minimum type sizes, line-heights, and spacing for each target script.

## Critical Principle

Non-Western design traditions are not adaptations of a Western original. They are co-equal design forces with their own histories, principles, and aesthetic logics. When this extension is active, the cultural tradition should shape the entire system — not be an afterthought appended to a Western foundation. If the primary audience uses Arabic script, the system is an Arabic design system that also supports Latin, not a Latin system with Arabic support bolted on.
