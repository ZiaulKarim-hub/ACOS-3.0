# Extension: Analog & Handcraft

**Activated when:** Textures, grain, or noise are present; hand-drawn or hand-lettered elements appear; the design deliberately embraces imperfection; print-craft aesthetics (letterpress, risograph, woodblock) are evident.

## What This Extension Adds

The core template assumes pixel-perfect, mathematically precise output. This extension provides specification structures for design systems that deliberately introduce controlled imperfection — the visual warmth of handcraft applied through digital means. The key word is "controlled": analog-inspired design is not random noise. It is a systematic vocabulary of imperfection governed by rules as rigorous as any rationalist system.

## Augmented Template Fields

### Texture Library (new field)

Define a library of texture overlays, each with: name, type (grain/noise/paper/fabric/ink/halftone/risograph), base opacity range (min-max, allowing variation), blend mode (multiply/overlay/soft-light), resolution (px or dpi), and usage context (backgrounds only / text containers / illustrations / all surfaces).

Examples: `{name: "paper-warm", type: "paper", opacity: [0.03, 0.08], blend: "multiply", usage: "page backgrounds"}`. Or: `{name: "riso-grain", type: "risograph", opacity: [0.05, 0.15], blend: "overlay", usage: "illustration backgrounds, card surfaces"}`.

Critical rule: textures must NEVER reduce text contrast below WCAG thresholds. Calculate contrast with texture at maximum opacity on both light and dark backgrounds.

### Imperfection Rules (new field)

Define controlled variation for specific element types. Each rule specifies: the element, the property that varies, the variation type (jitter, wobble, offset, rotation), and the variation range.

Examples: `{element: "divider-line", property: "stroke-width", variation: "jitter", range: "±0.3px"}`. Or: `{element: "icon-stroke", property: "path", variation: "wobble", range: "±0.5px displacement at control points"}`. Or: `{element: "card-container", property: "rotation", variation: "jitter", range: "±0.5deg"}`.

Imperfection must be reproducible — given the same seed or input, the same imperfection appears. This is controlled randomness, not true randomness.

### Process Color Palette (augments color.palettes)

Add a "process" palette that simulates print-process colors — slightly impure, as if mixed from CMYK inks rather than specified in pure RGB. Process colors are warmer, slightly less saturated, and have a subtle "dirty" quality that references physical printing. Define these as additional swatches within existing palette families: `{grade: "10-process", hex: "#f5f0e8"}` (a warm, paper-tinted near-white vs. the pure `#f4f4f4`).

### Hand-Drawn Typography (augments typography.typefaces)

Add a handwritten or hand-lettered typeface for display use. Specify: the face, the contexts where it is permitted (headlines only, pull-quotes, callouts — NEVER body text), the sizes at which it is legible, and pairing rules with the primary sans-serif.

### Illustration Variant: Hand-Drawn (augments iconography)

Define a hand-drawn icon variant style. Rules: consistent "hand" (the same imagined person drew all icons — consistent stroke weight variation, consistent wobble frequency), a defined pen type (felt-tip, ballpoint, brush, pencil), and a color palette subset (typically monochrome or limited to 2-3 colors from the process palette).

## Design Rules for Analog Systems

Analog aesthetics must earn their place through functional contribution — not nostalgia alone. Texture adds warmth and approachability. Imperfection humanizes an interface. Hand-drawn elements signal craft and care. But these qualities must serve the content, not obscure it.

Rules: Body text is ALWAYS rendered crisply in the primary sans-serif — no texture overlays on running text. Textures are background elements, never foreground. Imperfection jitter is subtle enough that a user cannot consciously detect individual deviations but feels the cumulative warmth. Process colors are used for backgrounds and large surfaces; pure palette colors are used for text and interactive elements where contrast is critical.

## Derivation Procedure

1. From Phase 1, classify the analog aesthetic: letterpress (heavy impression, debossed), risograph (misregistration, grain, limited spot colors), screen-print (halftone, thick ink), hand-drawn (pencil/pen/brush), collage (mixed media, cut edges), or hybrid.
2. From the influence dossier, identify craft traditions (Arts & Crafts, Japanese woodblock, punk/zine, etc.).
3. Define the texture library based on the identified aesthetic. Create or source texture assets at appropriate resolution.
4. Define imperfection rules that match the identified "hand" — the imagined physical process that produced the design.
5. Build the process color palette by adjusting the core palette toward the warm/impure direction.
6. Select or define a handwritten display typeface that complements the primary face.
7. Validate: ensure all textures pass the contrast test. Ensure imperfection is subtle enough that it reads as "warm" not "broken."

## Integration with Core System

Analog elements are a layer on top of the core system, not a replacement. The grid still governs layout. The type scale still governs size. The spacing tokens still govern rhythm. The analog layer adds texture, variation, and material quality to surfaces that would otherwise be flat and pristine. An artifact can be rendered with or without the analog layer and remain structurally sound — the layer adds character, not structure.
