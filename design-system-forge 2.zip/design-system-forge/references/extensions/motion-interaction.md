# Extension: Motion & Interaction

**Activated when:** Animations are prominent and complex, scroll-driven effects present, transitions feel physics-based, gesture interactions defined beyond tap/click.

## What This Extension Adds

The core motion section provides easing curves and durations — the equivalent of sheet music notation. This extension adds the orchestra: physics-based spring systems, gesture vocabularies, component state machines, choreographed multi-element sequences, haptic feedback definitions, and scroll-driven effects. For systems where motion IS the brand identity (not a garnish on static components), this extension is essential.

## Template Section 14: motion_interaction

### Spring Physics Presets

Spring animations are defined by three parameters: **tension** (stiffness of the spring), **friction** (damping — how quickly it settles), and **mass** (weight of the element). Different combinations produce distinct characters.

Standard presets to define:
- **snappy:** High tension (300-400), high friction (20-30), low mass (1). For micro-interactions: toggles, checkboxes, small state changes. Settles in <200ms.
- **responsive:** Medium tension (200-300), medium friction (15-25), low mass (1). For medium elements: dropdown open, accordion expand, card flip. Settles in 200-400ms.
- **gentle:** Low tension (100-200), medium friction (10-20), low mass (1). For large elements: modal entrance, page transitions, content reveal. Settles in 300-500ms.
- **bouncy:** High tension (300-400), low friction (8-15), low mass (1). For playful/expressive systems: notification pop-in, achievement celebration. Visible overshoot.
- **heavy:** Medium tension (150-250), high friction (25-35), high mass (2-3). For drag-and-drop, large panel slides, resize handles. Feels weighty and deliberate.

### Gesture Vocabulary

Each gesture definition specifies: the physical gesture, what triggers it, the system response, how to cancel it, and which components it applies to.

Core gestures to define: tap, double-tap, long-press, swipe (directional), pinch, spread, rotate, drag, pan, hover (desktop), force-touch (where supported).

Per gesture: `{gesture, trigger_condition, response_animation, spring_preset, cancellation_method, component_scope, fallback_for_non_touch}`.

Example: `{gesture: "swipe-left", trigger: "horizontal displacement > 60px on list-item", response: "reveal delete action, spring=snappy", cancellation: "swipe-right or release before threshold", scope: ["list-item", "notification-toast"], fallback: "show delete button on hover"}`.

### Component State Machines

For components with complex interaction states, define a formal state machine: states (nodes), transitions (edges), trigger events, and the animation that plays during each transition.

Example for a swipe-to-delete list item:
```
states: [idle, swiping, threshold-reached, action-confirmed, dismissed]
transitions:
  - {from: idle, to: swiping, trigger: "touch-start + horizontal-move", animation: "track finger, spring=none"}
  - {from: swiping, to: threshold-reached, trigger: "displacement > 60px", animation: "snap to action-reveal, spring=snappy"}
  - {from: threshold-reached, to: idle, trigger: "release before confirm", animation: "spring-back, spring=responsive"}
  - {from: threshold-reached, to: action-confirmed, trigger: "release after confirm", animation: "expand delete, spring=snappy"}
  - {from: action-confirmed, to: dismissed, trigger: "150ms delay", animation: "collapse height, spring=gentle"}
```

### Choreography Sequences

Multi-element animations that play in coordinated sequence. Each step specifies the target element, delay from sequence start, animation type, duration or spring preset, and easing.

Example for page load: `[{element: "header", delay: 0, animation: "fade-in + slide-down 8px", spring: "gentle"}, {element: "hero-text", delay: 80ms, animation: "fade-in + slide-up 16px", spring: "responsive"}, {element: "content-cards", delay: 160ms, animation: "stagger-fade-in 40ms per card", spring: "responsive"}]`.

Stagger rules: when animating a group (list items, grid cards), define the per-element delay (typically 30-60ms) and maximum total stagger (typically ≤400ms to avoid sluggishness).

### Haptic Feedback

For mobile/wearable targets, define haptic patterns. Each pattern specifies the trigger event, the haptic type (impact light/medium/heavy, notification success/warning/error, selection tick), and intensity.

### Scroll Effects

Define scroll-driven behaviors: parallax (element moves at fraction of scroll speed), reveal-on-scroll (element animates in when scrolled into viewport), sticky (element becomes fixed at scroll position), progress-linked (animation progress tied to scroll percentage).

For each effect: `{type, trigger_position ("element enters viewport" / "50% scroll"), behavior, reduced_motion_fallback}`.

### Reduced Motion Policy

Define exactly how the system degrades when `prefers-reduced-motion: reduce` is active. Options per animation type: disable entirely (recommended for decorative), reduce to opacity-only (for functional state changes), reduce to instant transition (for layout changes), keep but slow down (never recommended — slower ≠ less motion).

## Derivation Procedure

1. From Phase 1 motion observations, classify the overall motion character (snappy/smooth/springy/dramatic).
2. From the influence dossier, identify motion influences (iOS physics, Saul Bass, Material motion, choreographic design).
3. Map the observed character to spring preset values. If the sample feels "springy," the primary preset has lower friction (visible overshoot). If "smooth," higher friction (no overshoot).
4. Inventory all observed gestures and define them formally.
5. For each complex component, draw the state machine from observed behavior.
6. Define choreography sequences for page-level transitions.
7. Specify reduced motion policy for every animation category.

## Integration with Core System

Spring presets and gestures are referenced by components in their `behavior` field. The core `motion.easing_curves` remain available for CSS-only transitions; spring physics are used for JavaScript-driven animations. The two systems coexist — simple transitions use curves, complex interactions use springs.
